"""Independent preview renderer for the native AE scene. Python 3 + Pillow + numpy.
Run: python render_preview.py --poster 5.9 --out poster.png
Run: python render_preview.py --video silent.mp4 --scale 0.5
The preview is not an After Effects render. JSX is the editable delivery.
"""
from pathlib import Path
import argparse, json, math, os, subprocess, multiprocessing as mp
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent.parent
SCENE=json.loads((ROOT/'source/scene.json').read_text(encoding='utf-8'))
CACHE={}; FONT_CACHE={}; SCALE=1

def interp(keys,t,default,hold=False):
    if not keys:return default
    if t<=keys[0][0]:return keys[0][1]
    for i in range(1,len(keys)):
        b,vb=keys[i]; a,va=keys[i-1]
        if t<b:
            if hold:return va
            f=(t-a)/(b-a) if b>a else 1
            if isinstance(va,list):return [u+(v-u)*f for u,v in zip(va,vb)]
            return va+(vb-va)*f
    return keys[-1][1]

def prop(l,n,t,default,hold=False):return interp(l.get(n+'_keys'),t,l.get(n,default),hold)
def rgba(c):
    if c is None:return None
    return tuple(int(c[i:i+2],16) for i in (1,3,5))+(255,)
def font(size,bold):
    key=(size,bold)
    if key not in FONT_CACHE:
        suffix='Bold' if bold else 'Regular'
        f=Path('/usr/share/fonts/truetype/liberation/LiberationSans-'+suffix+'.ttf')
        if not f.exists():f=ROOT/'assets/fonts'/('LiberationSans-'+suffix+'.ttf')
        FONT_CACHE[key]=ImageFont.truetype(str(f),max(1,round(size*SCALE)))
    return FONT_CACHE[key]
def curve_points(g):
    vs=g['vertices']; ins=g['ins']; outs=g['outs']; pts=[]
    for i,p in enumerate(vs):
        q=vs[(i+1)%len(vs)]; c1=[p[j]+outs[i][j] for j in [0,1]]; c2=[q[j]+ins[(i+1)%len(vs)][j] for j in [0,1]]
        for s in range(21):
            u=s/20; v=1-u
            pts.append([v**3*p[j]+3*v*v*u*c1[j]+3*v*u*u*c2[j]+u**3*q[j] for j in [0,1]])
    return pts
def bounds(gs):
    pts=[]
    for g in gs:
        if g['type'] in ['ellipse','rect']:
            pts.extend([[g['x']-g['w']/2,g['y']-g['h']/2],[g['x']+g['w']/2,g['y']+g['h']/2]])
        elif g['type']=='path':pts.extend(curve_points(g))
        else:pts.extend(g['points'])
    pad=max([g.get('sw',0) for g in gs]+[0])/2+3
    return [math.floor(min(p[0] for p in pts)-pad),math.floor(min(p[1] for p in pts)-pad),
            math.ceil(max(p[0] for p in pts)+pad),math.ceil(max(p[1] for p in pts)+pad)]
def graphics_image(gs):
    b=bounds(gs); W=math.ceil((b[2]-b[0])*SCALE); H=math.ceil((b[3]-b[1])*SCALE)
    im=Image.new('RGBA',(max(1,W),max(1,H))); d=ImageDraw.Draw(im)
    def xy(p):return ((p[0]-b[0])*SCALE,(p[1]-b[1])*SCALE)
    for g in gs:
        ty=g['type']; fill=rgba(g.get('fill')); stroke=rgba(g.get('stroke')); sw=max(1,round(g.get('sw',1)*SCALE))
        if ty in ['rect','ellipse']:
            box=(*xy([g['x']-g['w']/2,g['y']-g['h']/2]),*xy([g['x']+g['w']/2,g['y']+g['h']/2]))
            if ty=='ellipse':d.ellipse(box,fill,stroke,sw)
            else:d.rounded_rectangle(box,round(g.get('r',0)*SCALE),fill,stroke,sw)
        elif ty in ['polygon','path']:
            pts=[xy(p) for p in (curve_points(g) if ty=='path' else g['points'])]
            d.polygon(pts,fill)
            if stroke:d.line(pts+[pts[0]],fill=stroke,width=sw,joint='curve')
        else:d.line([xy(p) for p in g['points']],fill=stroke,width=sw,joint='curve')
    return im,[-b[0]*SCALE,-b[1]*SCALE]

def text_image(l,t):
    val=prop(l,'text',t,'',True); key=('txt',val,l['size'],l['bold'],l['color'],l['align'],SCALE)
    if key in CACHE:return CACHE[key]
    f=font(l['size'],l['bold']); anchor={'left':'ls','right':'rs','center':'ms'}[l['align']]
    b=f.getbbox(val,anchor=anchor); pad=4
    im=Image.new('RGBA',(max(1,b[2]-b[0]+pad*2),max(1,b[3]-b[1]+pad*2)))
    ImageDraw.Draw(im).text((pad-b[0],pad-b[1]),val,font=f,fill=rgba(l['color']),anchor=anchor)
    result=(im,[pad-b[0],pad-b[1]]);CACHE[key]=result;return result

def layer_image(l,t):
    ty=l['type']
    if ty=='comp':
        im=render_comp(l['comp'],t); a=l.get('anchor',[0,0]);return im,[v*SCALE for v in a]
    if ty=='text':return text_image(l,t)
    key=(ty,l.get('file',l['name']),SCALE)
    if key not in CACHE:
        if ty=='shape':CACHE[key]=graphics_image(l['graphics'])
        elif ty=='image':
            im=Image.open(ROOT/l['file']).convert('RGBA')
            # Keep source sprite at full resolution; transform below uses SCALE.
            CACHE[key]=(im,l.get('anchor',[0,0]))
    return CACHE[key]

def composite(dest,src,anchor,pos,scale,rot,opacity):
    sx,sy=scale[0]/100,scale[1]/100
    if sx<=.0001 or sy<=.0001 or opacity<=0:return
    w,h=src.size
    if sx!=1 or sy!=1:
        src=src.resize((max(1,round(w*sx)),max(1,round(h*sy))),Image.Resampling.BICUBIC)
    ax,ay=anchor[0]*sx,anchor[1]*sy
    if abs(rot)>.01:
        w,h=src.size; rad=math.radians(rot)
        rx=(ax-w/2)*math.cos(rad)-(ay-h/2)*math.sin(rad)
        ry=(ax-w/2)*math.sin(rad)+(ay-h/2)*math.cos(rad)
        src=src.rotate(-rot,Image.Resampling.BICUBIC,expand=True)
        ax,ay=rx+src.width/2,ry+src.height/2
    if opacity<99.99:
        src=src.copy();src.putalpha(src.getchannel('A').point(lambda x:round(x*opacity/100)))
    x,y=round(pos[0]-ax),round(pos[1]-ay)
    if x>=dest.width or y>=dest.height or x+src.width<=0 or y+src.height<=0:return
    dest.alpha_composite(src,(x,y))

def render_comp(name,t):
    c=SCENE['comps'][name]; out=Image.new('RGBA',(round(c['w']*SCALE),round(c['h']*SCALE)))
    for l in c['layers']:
        op=prop(l,'opacity',t,100); sc=prop(l,'scale',t,[100,100])
        if op<.1 or sc[0]<.1 or sc[1]<.1:continue
        im,a=layer_image(l,t); p=prop(l,'pos',t,[0,0]);r=prop(l,'rotation',t,0)
        if l['type']=='image':sc=[v*SCALE for v in sc]
        composite(out,im,a,[v*SCALE for v in p],sc,r,op)
    return out

def frame(i):return render_comp(SCENE['master'],i/SCENE['fps']).convert('RGB').tobytes()
def init(scale):
    global SCALE
    SCALE=scale

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--poster',type=float);ap.add_argument('--out');ap.add_argument('--video');ap.add_argument('--scale',type=float,default=1);ap.add_argument('--workers',type=int,default=4)
    args=ap.parse_args();SCALE=args.scale
    if args.poster is not None:
        render_comp(SCENE['master'],args.poster).convert('RGB').save(args.out)
    else:
        cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f"{round(1080*SCALE)}x{round(1920*SCALE)}",'-r',str(SCENE['fps']),'-i','-',
             '-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',args.video]
        p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
        with mp.Pool(args.workers,initializer=init,initargs=(SCALE,)) as pool:
            for i,buf in enumerate(pool.imap(frame,range(round(SCENE['duration']*SCENE['fps'])),chunksize=1)):
                p.stdin.write(buf)
                if i%30==0:print(f'{i}/{round(SCENE["duration"]*SCENE["fps"])} frames',flush=True)
        p.stdin.close(); ret=p.wait()
        if ret:raise SystemExit(ret)
