// Narrow AE API simulation, NOT an actual After Effects runtime.
// Exercises the complete generated builder, property ownership, indexed-group
// invalidation, animation, source-text styles, asset imports and expressions.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const PKG=path.resolve(__dirname,'..');
const scene=JSON.parse(fs.readFileSync(PKG+'/source/scene.json','utf8'));
const schema={
 'ADBE Transform Group':{'ADBE Anchor Point':[0,0],'ADBE Position':[0,0],'ADBE Scale':[100,100],'ADBE Rotate Z':0,'ADBE Opacity':100},
 'ADBE Vector Shape - Rect':{'ADBE Vector Rect Size':[100,100],'ADBE Vector Rect Position':[0,0],'ADBE Vector Rect Roundness':0},
 'ADBE Vector Shape - Ellipse':{'ADBE Vector Ellipse Size':[100,100],'ADBE Vector Ellipse Position':[0,0]},
 'ADBE Vector Shape - Group':{'ADBE Vector Shape':null},
 'ADBE Vector Graphic - Fill':{'ADBE Vector Fill Color':[1,1,1],'ADBE Vector Fill Opacity':100},
 'ADBE Vector Graphic - Stroke':{'ADBE Vector Stroke Color':[1,1,1],'ADBE Vector Stroke Width':2,'ADBE Vector Stroke Line Cap':1,'ADBE Vector Stroke Line Join':1},
 'ADBE Slider Control':{'ADBE Slider Control-0001':0},
 'ADBE Audio Group':{'ADBE Audio Levels':[0,0]}
};
function run(file,expectBroken=false,missingFont=false){
 let saved=null,alerts=[],project=null,styled=0,imports=0,context;
 class Doc {
  constructor(text,bound=false){this.text=text;this.bound=bound;this._font='ArialMT';this.fontSize=12;}
  get font(){return this._font;}
  set font(v){
   if(!this.bound)throw Error('Unable to set value as it is not associated with a layer.');
   if(missingFont&&v==='Arial-BoldMT')throw Error('Simulated missing Arial Bold');
   this._font=v;styled++;
  }
  resetCharStyle(){if(!this.bound)throw Error('TextDocument is detached');}
  clone(){return Object.assign(new Doc(this.text,this.bound),this);}
 }
 class Prop {
  constructor(name,val,owner){this.name=name;this.matchName=name;this._value=val;this.owner=owner;this.propertyType=1;this.keys=[];this.expression='';this.invalid=false;}
  check(){if(this.invalid)throw Error('Object is Invalid: '+this.name);}
  get canSetExpression(){return true;}
  get expressionEnabled(){return !!this.expression;}
  get expressionError(){try{if(this.expression)this.valueAtTime(7.1,false);return '';}catch(e){return e.message;}}
  get isSpatial(){return this.matchName==='ADBE Position';}
  get propertyValueType(){return this.isSpatial?'TwoD_SPATIAL':'Other';}
  get value(){this.check();const v=this._value;return v instanceof Doc?v.clone():v;}
  setValue(v){this.check();assert.equal(this.keys.length,0,'setValue on animated property');this._value=v instanceof Doc?v.clone():v;}
  setValueAtTime(t,v){this.check();assert(Number.isFinite(t));const old=this.keys.find(k=>k.t===t);const n={t,v:v instanceof Doc?v.clone():v,hold:false};if(old)Object.assign(old,n);else this.keys.push(n);this.keys.sort((a,b)=>a.t-b.t);}
  nearestKeyIndex(t){this.check();let best=0;this.keys.forEach((k,i)=>{if(Math.abs(k.t-t)<Math.abs(this.keys[best].t-t))best=i;});return best+1;}
  setInterpolationTypeAtKey(i,a,b){this.check();assert(this.keys[i-1]);this.keys[i-1].hold=a==='HOLD';}
  setSpatialAutoBezierAtKey(i,v){this.check();assert(this.isSpatial);assert(this.keys[i-1]);}
  setSpatialContinuousAtKey(i,v){this.setSpatialAutoBezierAtKey(i,v);}
  setSpatialTangentsAtKey(i,a,b){this.setSpatialAutoBezierAtKey(i,false);assert.equal(a.length,2);assert.equal(b.length,2);}
  valueAtTime(t,pre){
   this.check();
   if(this.expression&&!pre){return vm.runInNewContext(this.expression,{time:t,thisComp:adapter(this.owner.comp,t),comp:n=>adapter(project.comps.find(c=>c.name===n),t)});}
   if(!this.keys.length)return this.value;
   let prev=this.keys[0];
   for(const next of this.keys.slice(1)){
    if(t<next.t){if(prev.hold||prev.v instanceof Doc)return prev.v;let f=Math.max(0,(t-prev.t)/(next.t-prev.t));return Array.isArray(prev.v)?prev.v.map((v,i)=>v+(next.v[i]-v)*f):prev.v+(next.v-prev.v)*f;}
    prev=next;
   }
   return prev.v;
  }
  clone(){const p=new Prop(this.matchName,this._value,this.owner);Object.assign(p,this,{invalid:false,keys:this.keys.map(k=>({...k}))});return p;}
 }
 class Group {
  constructor(name,owner){this.name=name;this.matchName=name;this.owner=owner;this.propertyType=2;this.children=[];this.invalid=false;
   if(schema[name])for(const [key,val] of Object.entries(schema[name]))this.children.push(new Prop(key,val,owner));
   if(name==='ADBE Vector Group')this.children.push(new Group('ADBE Vectors Group',owner));
  }
  check(){if(this.invalid)throw Error('Object is Invalid: '+this.name);}
  get numProperties(){return this.children.length;}
  property(n){this.check();const p=typeof n==='number'?this.children[n-1]:this.children.find(p=>p.name===n||p.matchName===n);if(!p)throw Error('Unknown property '+n+' in '+this.matchName);return p;}
  addProperty(n){this.check();assert(schema[n]||n==='ADBE Vector Group','Unsupported property '+n);
   const old=this.children;this.children=old.map(p=>p.clone());old.forEach(invalidate);
   const gr=new Group(n,this.owner);this.children.push(gr);return gr;
  }
  clone(){const g=new Group(this.matchName,this.owner);g.name=this.name;g.children=this.children.map(p=>p.clone());return g;}
 }
 function invalidate(o){o.invalid=true;if(o.children)o.children.forEach(invalidate);}
 class Layer extends Group {
  constructor(kind,c,source){super('Layer',null);this.owner=this;this.comp=c;this.kind=kind;this.name=kind;this.source=source;this.children=[new Group('ADBE Transform Group',this),new Group('ADBE Effect Parade',this)];
   if(kind==='shape')this.children.push(new Group('ADBE Root Vectors Group',this));
   if(kind==='text'){const g=new Group('ADBE Text Properties',this);g.children.push(new Prop('ADBE Text Document',new Doc(source,true),this));this.children.push(g);}
   if(source&&source.isAudio)this.children.push(new Group('ADBE Audio Group',this));
  }
  moveToEnd(){this.comp.list=this.comp.list.filter(l=>l!==this);this.comp.list.push(this);}
 }
 class Comp {
  constructor(n,w,h,pa,d,f){this.name=n;this.width=w;this.height=h;this.duration=d;this.frameRate=f;this.list=[];this.markerProperty=new Prop('markers',null,null);this.time=0;
   const add=(kind,src)=>{let l=new Layer(kind,this,src);this.list.unshift(l);return l;};
   this.layers={addShape:()=>add('shape'),addText:t=>add('text',t),add:s=>add('av',s),addNull:()=>add('null')};
  }
  get numLayers(){return this.list.length;}
  layer(n){const l=typeof n==='number'?this.list[n-1]:this.list.find(l=>l.name===n);if(!l)throw Error('Missing layer '+n);return l;}
  openInViewer(){this.opened=true;}
 }
 function adapter(c,t){
  assert(c,'Missing expression comp');
  return {
   layer(n){
    const l=c.layer(n);
    return {
     effect(name){
      const g=l.property('ADBE Effect Parade').property(name);
      return i=>{
       const p=g.property(i);
       return {value:p.valueAtTime(t,true),valueOf(){return this.value;}};
      };
     }
    };
   }
  };
 }
 function File(p){return {fsName:p,exists:fs.existsSync(p),parent:{fsName:path.dirname(p)}};}
 File.saveDialog=()=>null;
 context={File,$:{fileName:file},TextDocument:Doc,Shape:class{},ImportOptions:class{constructor(f){this.file=f;}},MarkerValue:class{constructor(t){this.comment=t;}},
  KeyframeInterpolationType:{HOLD:'HOLD',LINEAR:'LINEAR'},ParagraphJustification:{LEFT_JUSTIFY:0,RIGHT_JUSTIFY:1,CENTER_JUSTIFY:2},
  PropertyType:{PROPERTY:1},PropertyValueType:{ThreeD_SPATIAL:'ThreeD_SPATIAL'},AlphaMode:{STRAIGHT:'straight'},alert:m=>alerts.push(m),confirm:()=>true,
  app:{project:{numItems:0},beginUndoGroup(){},endUndoGroup(){},newProject(){
   project={comps:[],items:{addFolder(n){return {name:n};},addComp(...args){const c=new Comp(...args);project.comps.push(c);return c;}},
    importFile(o){assert(fs.existsSync(o.file.fsName));imports++;const isAudio=o.file.fsName.endsWith('.wav');return {name:path.basename(o.file.fsName),duration:isAudio?1.6:0,isAudio,mainSource:{}};},
    save(f){saved=f.fsName;}};return project;
  }}
 };
 const code=fs.readFileSync(file,'utf8').replace(/^#target.*$/m,'');
 // Run with the correct package base while allowing an older script copy as input.
 context.$.fileName=PKG+'/BUILD_CHICKEN_ROAD.jsx';
 vm.runInNewContext(code,context,{timeout:20000});
 if(expectBroken){assert.equal(saved,null);assert(alerts.some(s=>s.includes('not associated with a layer')));assert.equal(project.comps.find(c=>c.name===scene.master).numLayers,3);return 'Original script reproduces the user-reported failure at text layer 1';}
 assert(saved&&saved.includes('v1_1'),'Project not saved: '+alerts.join('\n'));
 assert(!alerts.some(s=>s.includes('build failed')||s.includes('Expression diagnostics')),'Build failure: '+alerts.join('\n'));
 const master=project.comps.find(c=>c.name===scene.master);
 for(const c of project.comps){assert.equal(c.numLayers,scene.comps[c.name].layers.length+(c===master?14:0));}
 assert.equal(imports,5);assert(styled>50||missingFont);
 for(const c of project.comps){for(const spec of scene.comps[c.name].layers){
   const l=c.layer(spec.name);const p=l.property('ADBE Transform Group').property('ADBE Position');
   if(!spec.pos_keys)assert.deepEqual(p.value,spec.pos);
   if(spec.type==='text'){
    const d=l.property('ADBE Text Properties').property('ADBE Text Document').value;
    assert.equal(d.fontSize,spec.size);assert(d.bound);
   }
  }}
 function value(c,l,t){return c.layer(l).property('ADBE Text Properties').property('ADBE Text Document').valueAtTime(t,false);}
 assert.equal(value(master,'ROUND / current multiplier',5.9),'1.23x');
 assert.equal(value(master,'CASH OUT / amount',5.9),'61.50 $');
 assert.equal(value(master,'BALANCE / amount',0),'1 000 000.00');
 assert.equal(value(master,'BALANCE / amount',1),'999 950.00');
 assert.equal(value(master,'BALANCE / amount',7.1),'1 000 011.50');
 const win=project.comps.find(c=>c.name==='04_WIN_CARD');
 assert.equal(value(win,'WIN / amount',7.1),'+61.50 $');
 assert.equal(value(win,'WIN / multiplier',7.1),'x1.23');
 master.layer('00_CONTROLS').property('ADBE Effect Parade').property('BET_AMOUNT').property(1).setValue(100);
 assert.equal(value(master,'CASH OUT / amount',5.9),'123.00 $');
 assert.equal(value(master,'BALANCE / amount',7.1),'1 000 023.00');
 assert.equal(value(win,'WIN / amount',7.1),'+123.00 $');
 assert(master.opened);
 return `Complete builder PASS: ${project.comps.length} comps, ${project.comps.reduce((n,c)=>n+c.numLayers,0)} layers, ${imports} assets, ${styled} text-style assignments`+(missingFont?' (font fallback case)':'');
}
if(process.argv[2])console.log(run(process.argv[2],true));
console.log(run(PKG+'/BUILD_CHICKEN_ROAD.jsx'));
console.log(run(PKG+'/BUILD_CHICKEN_ROAD.jsx',false,true));
console.log('Scope: simulated AE API only; actual AE execution remains unverified.');
