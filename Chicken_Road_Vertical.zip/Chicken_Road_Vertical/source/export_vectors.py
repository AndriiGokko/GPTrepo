"""Exports the scene's authored vector graphics for reuse outside After Effects."""
from pathlib import Path
import json, html
from render_preview import bounds
ROOT=Path(__file__).resolve().parent.parent
data=json.loads((ROOT/'source/scene.json').read_text())
layers={l['name']:l for c in data['comps'].values() for l in c['layers']}

def element(g):
    typ=g['type'];style=f'fill="{g.get("fill") or "none"}" stroke="{g.get("stroke") or "none"}" stroke-width="{g.get("sw",0)}" stroke-linecap="round" stroke-linejoin="round"'
    if typ=='rect':return f'<rect x="{g["x"]-g["w"]/2}" y="{g["y"]-g["h"]/2}" width="{g["w"]}" height="{g["h"]}" rx="{g.get("r",0)}" {style}/>'
    if typ=='ellipse':return f'<ellipse cx="{g["x"]}" cy="{g["y"]}" rx="{g["w"]/2}" ry="{g["h"]/2}" {style}/>'
    if typ=='path':
        vs=g['vertices'];d=f'M {vs[0][0]} {vs[0][1]}'
        for i,p in enumerate(vs):
            j=(i+1)%len(vs);q=vs[j];o=g['outs'][i];a=g['ins'][j]
            d+=f' C {p[0]+o[0]} {p[1]+o[1]} {q[0]+a[0]} {q[1]+a[1]} {q[0]} {q[1]}'
        return f'<path d="{d} Z" {style}/>'
    points=' '.join(f'{p[0]},{p[1]}' for p in g['points'])
    tag='polyline' if typ=='line' else 'polygon'
    return f'<{tag} points="{points}" {style}/>'

assets={'coin_inactive':'COIN 01 / inactive','coin_active':'COIN 01 / reached',
        'coin_collected':'COIN 01 / collected gold','fire':'FIRE 01 / vector burst',
        'road_tile':'LANE 01 / asphalt','drain_grate':'LANE 01 / grate',
        'start_gate':'START / arched gate','button_go':'GO / button',
        'button_cashout':'CASH OUT / button','win_card':'WIN / card'}
out=ROOT/'assets/vectors';out.mkdir(exist_ok=True)
for name,source in assets.items():
    gs=layers[source]['graphics'];x0,y0,x1,y1=bounds(gs)
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x0} {y0} {x1-x0} {y1-y0}" width="{x1-x0}" height="{y1-y0}">\n'
    svg+='<title>'+html.escape(source)+'</title>\n'+'\n'.join(element(g) for g in gs)+'\n</svg>'
    (out/(name+'.svg')).write_text(svg)
print('Exported',len(assets),'original SVG assets')
