#target aftereffects
/*
CHICKEN ROAD VERTICAL - native scene builder for After Effects 2025 / 2026.
Unzip the complete folder before running. No third-party effects required.
The builder never silently closes an unsaved project and never overwrites an AEP.
*/
(function () {
    var SCENE = {
  "width": 1080,
  "height": 1920,
  "fps": 30,
  "duration": 9.5,
  "version": "1.0",
  "title": "CHICKEN ROAD / VERTICAL",
  "comps": {
    "03_ROAD_WORLD": {
      "w": 3230,
      "h": 870,
      "layers": [
        {
          "type": "shape",
          "name": "ROAD / base",
          "graphics": [
            {
              "type": "rect",
              "x": 1615,
              "y": 435,
              "w": 3230,
              "h": 870,
              "fill": "#3C4264",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 00 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 142,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3B4262",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 261.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 159,
              "y": 141,
              "w": 62,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 95,
              "y": 172,
              "w": 55,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 138,
              "y": 537,
              "w": 67,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 143,
              "y": 634,
              "w": 80,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 179,
              "y": 594,
              "w": 66,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 01 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 380,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3F4668",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 499.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 414,
              "y": 225,
              "w": 54,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 344,
              "y": 661,
              "w": 57,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 447,
              "y": 521,
              "w": 75,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 396,
              "y": 640,
              "w": 44,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 411,
              "y": 578,
              "w": 57,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 01 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            380,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 02 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 618,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3B4262",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 737.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 657,
              "y": 523,
              "w": 75,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 616,
              "y": 632,
              "w": 59,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 680,
              "y": 602,
              "w": 62,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 666,
              "y": 155,
              "w": 63,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 603,
              "y": 640,
              "w": 55,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 02 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            618,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 03 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 856,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3F4668",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 975.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 805,
              "y": 223,
              "w": 71,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 793,
              "y": 654,
              "w": 66,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 914,
              "y": 234,
              "w": 80,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 853,
              "y": 146,
              "w": 73,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 842,
              "y": 222,
              "w": 53,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 03 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            856,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 04 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 1094,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3B4262",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1213.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1062,
              "y": 234,
              "w": 49,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1148,
              "y": 527,
              "w": 62,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1027,
              "y": 649,
              "w": 79,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1042,
              "y": 512,
              "w": 75,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1047,
              "y": 577,
              "w": 63,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 04 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1094,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 05 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 1332,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3F4668",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1451.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1370,
              "y": 581,
              "w": 61,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1347,
              "y": 208,
              "w": 62,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1380,
              "y": 576,
              "w": 55,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1293,
              "y": 229,
              "w": 63,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1342,
              "y": 658,
              "w": 46,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 05 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1332,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 06 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 1570,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3B4262",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1689.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1546,
              "y": 575,
              "w": 47,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1586,
              "y": 231,
              "w": 59,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1594,
              "y": 167,
              "w": 67,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1539,
              "y": 532,
              "w": 63,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1531,
              "y": 609,
              "w": 70,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 06 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1570,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 07 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 1808,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3F4668",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1927.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1847,
              "y": 595,
              "w": 49,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1781,
              "y": 663,
              "w": 81,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1831,
              "y": 201,
              "w": 48,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1873,
              "y": 514,
              "w": 53,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1770,
              "y": 576,
              "w": 75,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 07 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1808,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 08 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 2046,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3B4262",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2165.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1984,
              "y": 172,
              "w": 71,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 1995,
              "y": 595,
              "w": 80,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2022,
              "y": 576,
              "w": 80,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2105,
              "y": 226,
              "w": 44,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2039,
              "y": 151,
              "w": 55,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 08 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            2046,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 09 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 2284,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3F4668",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2403.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2313,
              "y": 595,
              "w": 61,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2349,
              "y": 240,
              "w": 49,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2347,
              "y": 593,
              "w": 44,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2325,
              "y": 668,
              "w": 55,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2348,
              "y": 160,
              "w": 64,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 09 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            2284,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 10 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 2522,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3B4262",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2641.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2489,
              "y": 642,
              "w": 50,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2582,
              "y": 164,
              "w": 58,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2476,
              "y": 519,
              "w": 45,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2511,
              "y": 220,
              "w": 62,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2542,
              "y": 587,
              "w": 76,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 10 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            2522,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 11 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 2760,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3F4668",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2879.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2695,
              "y": 535,
              "w": 75,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2801,
              "y": 224,
              "w": 49,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2807,
              "y": 665,
              "w": 47,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2776,
              "y": 151,
              "w": 54,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2810,
              "y": 583,
              "w": 65,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 11 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            2760,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 12 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 2998,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3B4262",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3117.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2968,
              "y": 634,
              "w": 53,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2986,
              "y": 610,
              "w": 65,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3032,
              "y": 180,
              "w": 68,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3018,
              "y": 227,
              "w": 60,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 2958,
              "y": 586,
              "w": 63,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 12 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            2998,
            740
          ]
        },
        {
          "type": "shape",
          "name": "LANE 13 / asphalt",
          "graphics": [
            {
              "type": "rect",
              "x": 3236,
              "y": 427,
              "w": 238,
              "h": 728,
              "fill": "#3F4668",
              "r": 0,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 84,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 138,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 192,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 246,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 300,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 354,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 408,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 462,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 516,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 570,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 624,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 678,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3355.0,
              "y": 732,
              "w": 5,
              "h": 25,
              "fill": "#7F8BB3",
              "r": 2,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3303,
              "y": 517,
              "w": 67,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3179,
              "y": 666,
              "w": 48,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3189,
              "y": 236,
              "w": 75,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3290,
              "y": 532,
              "w": 50,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 3297,
              "y": 528,
              "w": 66,
              "h": 35,
              "fill": "#343B5A",
              "r": 10,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "LANE 13 / grate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 144,
              "h": 190,
              "fill": "#272E48",
              "r": 72,
              "stroke": "#505B83",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 6,
              "w": 124,
              "h": 175,
              "fill": "#363E60",
              "r": 62,
              "stroke": "#202842",
              "sw": 4
            },
            {
              "type": "rect",
              "x": -42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": -14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -9.0,
              "w": 7,
              "h": 102.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 14,
              "y": -5.5,
              "w": 7,
              "h": 95.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 28,
              "y": -2.0,
              "w": 7,
              "h": 88.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 42,
              "y": 1.5,
              "w": 7,
              "h": 81.0,
              "fill": "#1F2844",
              "r": 3,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": 60,
              "w": 164,
              "h": 12,
              "fill": "#64719B",
              "r": 6,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            3236,
            740
          ]
        },
        {
          "type": "shape",
          "name": "START / arched gate",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 162,
              "h": 510,
              "fill": "#262D46",
              "r": 81,
              "stroke": "#525D81",
              "sw": 5
            },
            {
              "type": "rect",
              "x": 0,
              "y": 8,
              "w": 137,
              "h": 489,
              "fill": "#14192B",
              "r": 69,
              "stroke": "#1D243A",
              "sw": 4
            }
          ],
          "pos": [
            142,
            592
          ]
        },
        {
          "type": "text",
          "name": "START / label",
          "text": "START",
          "pos": [
            142,
            505
          ],
          "size": 20,
          "color": "#7782A5",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "LANE 01 / active glow",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 228,
              "h": 716,
              "fill": "#416850",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            380,
            433
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              1.38,
              0
            ],
            [
              1.5,
              65
            ],
            [
              2.43,
              65
            ],
            [
              2.59,
              15
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 01 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            380,
            340
          ],
          "opacity_keys": [
            [
              0,
              100
            ],
            [
              1.38,
              100
            ],
            [
              1.43,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 01 / reached",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 7,
              "w": 188,
              "h": 188,
              "fill": "#234D3B",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 180,
              "fill": "#25843E",
              "stroke": "#193D32",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#30C657",
              "stroke": "#5EEA7D",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 4,
              "w": 133,
              "h": 133,
              "fill": "#2DB950",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#ABFFC1",
              "sw": 5
            }
          ],
          "pos": [
            380,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              1.38,
              0
            ],
            [
              1.43,
              100
            ],
            [
              2.43,
              100
            ],
            [
              2.5,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              1.38,
              [
                100,
                100
              ]
            ],
            [
              1.48,
              [
                112,
                112
              ]
            ],
            [
              1.62,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 01 / multiplier",
          "text": "1.03x",
          "pos": [
            380,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              78
            ],
            [
              1.38,
              78
            ],
            [
              1.43,
              100
            ],
            [
              2.43,
              100
            ],
            [
              2.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 01 / collected gold",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 5,
              "w": 134,
              "h": 134,
              "fill": "#80551A",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 134,
              "h": 134,
              "fill": "#F5B91A",
              "stroke": "#B37C16",
              "sw": 5
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 113,
              "h": 113,
              "fill": "#FFD944",
              "stroke": "#FFE788",
              "sw": 5
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 89,
              "h": 89,
              "fill": "#ECB223",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -40,
                  -30
                ],
                [
                  -30,
                  -40
                ],
                [
                  -17,
                  -46
                ]
              ],
              "stroke": "#FFF2B2",
              "sw": 5
            }
          ],
          "pos": [
            380,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.43,
              0
            ],
            [
              2.5,
              100
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              2.43,
              [
                10,
                100
              ]
            ],
            [
              2.59,
              [
                110,
                110
              ]
            ],
            [
              2.69,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 01 / gold symbol",
          "text": "$",
          "pos": [
            380,
            357
          ],
          "size": 48,
          "color": "#B48118",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.43,
              0
            ],
            [
              2.53,
              100
            ]
          ]
        },
        {
          "type": "text",
          "name": "LANE 01 / number",
          "text": "01",
          "pos": [
            380,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "LANE 02 / active glow",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 228,
              "h": 716,
              "fill": "#416850",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            618,
            433
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.43,
              0
            ],
            [
              2.55,
              65
            ],
            [
              3.48,
              65
            ],
            [
              3.64,
              15
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 02 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            618,
            340
          ],
          "opacity_keys": [
            [
              0,
              100
            ],
            [
              2.43,
              100
            ],
            [
              2.48,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 02 / reached",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 7,
              "w": 188,
              "h": 188,
              "fill": "#234D3B",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 180,
              "fill": "#25843E",
              "stroke": "#193D32",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#30C657",
              "stroke": "#5EEA7D",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 4,
              "w": 133,
              "h": 133,
              "fill": "#2DB950",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#ABFFC1",
              "sw": 5
            }
          ],
          "pos": [
            618,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.43,
              0
            ],
            [
              2.48,
              100
            ],
            [
              3.48,
              100
            ],
            [
              3.55,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              2.43,
              [
                100,
                100
              ]
            ],
            [
              2.53,
              [
                112,
                112
              ]
            ],
            [
              2.67,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 02 / multiplier",
          "text": "1.07x",
          "pos": [
            618,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              78
            ],
            [
              2.43,
              78
            ],
            [
              2.48,
              100
            ],
            [
              3.48,
              100
            ],
            [
              3.55,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 02 / collected gold",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 5,
              "w": 134,
              "h": 134,
              "fill": "#80551A",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 134,
              "h": 134,
              "fill": "#F5B91A",
              "stroke": "#B37C16",
              "sw": 5
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 113,
              "h": 113,
              "fill": "#FFD944",
              "stroke": "#FFE788",
              "sw": 5
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 89,
              "h": 89,
              "fill": "#ECB223",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -40,
                  -30
                ],
                [
                  -30,
                  -40
                ],
                [
                  -17,
                  -46
                ]
              ],
              "stroke": "#FFF2B2",
              "sw": 5
            }
          ],
          "pos": [
            618,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.48,
              0
            ],
            [
              3.55,
              100
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              3.48,
              [
                10,
                100
              ]
            ],
            [
              3.64,
              [
                110,
                110
              ]
            ],
            [
              3.74,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 02 / gold symbol",
          "text": "$",
          "pos": [
            618,
            357
          ],
          "size": 48,
          "color": "#B48118",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.48,
              0
            ],
            [
              3.58,
              100
            ]
          ]
        },
        {
          "type": "text",
          "name": "LANE 02 / number",
          "text": "02",
          "pos": [
            618,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "LANE 03 / active glow",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 228,
              "h": 716,
              "fill": "#416850",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            856,
            433
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.48,
              0
            ],
            [
              3.6,
              65
            ],
            [
              4.53,
              65
            ],
            [
              4.69,
              15
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 03 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            856,
            340
          ],
          "opacity_keys": [
            [
              0,
              100
            ],
            [
              3.48,
              100
            ],
            [
              3.53,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 03 / reached",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 7,
              "w": 188,
              "h": 188,
              "fill": "#234D3B",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 180,
              "fill": "#25843E",
              "stroke": "#193D32",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#30C657",
              "stroke": "#5EEA7D",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 4,
              "w": 133,
              "h": 133,
              "fill": "#2DB950",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#ABFFC1",
              "sw": 5
            }
          ],
          "pos": [
            856,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.48,
              0
            ],
            [
              3.53,
              100
            ],
            [
              4.53,
              100
            ],
            [
              4.6,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              3.48,
              [
                100,
                100
              ]
            ],
            [
              3.58,
              [
                112,
                112
              ]
            ],
            [
              3.72,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 03 / multiplier",
          "text": "1.12x",
          "pos": [
            856,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              78
            ],
            [
              3.48,
              78
            ],
            [
              3.53,
              100
            ],
            [
              4.53,
              100
            ],
            [
              4.6,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 03 / collected gold",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 5,
              "w": 134,
              "h": 134,
              "fill": "#80551A",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 134,
              "h": 134,
              "fill": "#F5B91A",
              "stroke": "#B37C16",
              "sw": 5
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 113,
              "h": 113,
              "fill": "#FFD944",
              "stroke": "#FFE788",
              "sw": 5
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 89,
              "h": 89,
              "fill": "#ECB223",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -40,
                  -30
                ],
                [
                  -30,
                  -40
                ],
                [
                  -17,
                  -46
                ]
              ],
              "stroke": "#FFF2B2",
              "sw": 5
            }
          ],
          "pos": [
            856,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.53,
              0
            ],
            [
              4.6,
              100
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              4.53,
              [
                10,
                100
              ]
            ],
            [
              4.69,
              [
                110,
                110
              ]
            ],
            [
              4.79,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 03 / gold symbol",
          "text": "$",
          "pos": [
            856,
            357
          ],
          "size": 48,
          "color": "#B48118",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.53,
              0
            ],
            [
              4.63,
              100
            ]
          ]
        },
        {
          "type": "text",
          "name": "LANE 03 / number",
          "text": "03",
          "pos": [
            856,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "LANE 04 / active glow",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 228,
              "h": 716,
              "fill": "#416850",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1094,
            433
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.53,
              0
            ],
            [
              4.65,
              65
            ],
            [
              5.58,
              65
            ],
            [
              5.74,
              15
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 04 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            1094,
            340
          ],
          "opacity_keys": [
            [
              0,
              100
            ],
            [
              4.53,
              100
            ],
            [
              4.58,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 04 / reached",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 7,
              "w": 188,
              "h": 188,
              "fill": "#234D3B",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 180,
              "fill": "#25843E",
              "stroke": "#193D32",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#30C657",
              "stroke": "#5EEA7D",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 4,
              "w": 133,
              "h": 133,
              "fill": "#2DB950",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#ABFFC1",
              "sw": 5
            }
          ],
          "pos": [
            1094,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.53,
              0
            ],
            [
              4.58,
              100
            ],
            [
              5.58,
              100
            ],
            [
              5.65,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              4.53,
              [
                100,
                100
              ]
            ],
            [
              4.63,
              [
                112,
                112
              ]
            ],
            [
              4.77,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 04 / multiplier",
          "text": "1.17x",
          "pos": [
            1094,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              78
            ],
            [
              4.53,
              78
            ],
            [
              4.58,
              100
            ],
            [
              5.58,
              100
            ],
            [
              5.65,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 04 / collected gold",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 5,
              "w": 134,
              "h": 134,
              "fill": "#80551A",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 134,
              "h": 134,
              "fill": "#F5B91A",
              "stroke": "#B37C16",
              "sw": 5
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 113,
              "h": 113,
              "fill": "#FFD944",
              "stroke": "#FFE788",
              "sw": 5
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 89,
              "h": 89,
              "fill": "#ECB223",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -40,
                  -30
                ],
                [
                  -30,
                  -40
                ],
                [
                  -17,
                  -46
                ]
              ],
              "stroke": "#FFF2B2",
              "sw": 5
            }
          ],
          "pos": [
            1094,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.58,
              0
            ],
            [
              5.65,
              100
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              5.58,
              [
                10,
                100
              ]
            ],
            [
              5.74,
              [
                110,
                110
              ]
            ],
            [
              5.84,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 04 / gold symbol",
          "text": "$",
          "pos": [
            1094,
            357
          ],
          "size": 48,
          "color": "#B48118",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.58,
              0
            ],
            [
              5.68,
              100
            ]
          ]
        },
        {
          "type": "text",
          "name": "LANE 04 / number",
          "text": "04",
          "pos": [
            1094,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "LANE 05 / active glow",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 228,
              "h": 716,
              "fill": "#416850",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1332,
            433
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.58,
              0
            ],
            [
              5.7,
              65
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 05 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            1332,
            340
          ],
          "opacity_keys": [
            [
              0,
              100
            ],
            [
              5.58,
              100
            ],
            [
              5.63,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "COIN 05 / reached",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 7,
              "w": 188,
              "h": 188,
              "fill": "#234D3B",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 180,
              "h": 180,
              "fill": "#25843E",
              "stroke": "#193D32",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#30C657",
              "stroke": "#5EEA7D",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 4,
              "w": 133,
              "h": 133,
              "fill": "#2DB950",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#ABFFC1",
              "sw": 5
            }
          ],
          "pos": [
            1332,
            340
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.58,
              0
            ],
            [
              5.63,
              100
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              5.58,
              [
                100,
                100
              ]
            ],
            [
              5.68,
              [
                112,
                112
              ]
            ],
            [
              5.82,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "COIN 05 / multiplier",
          "text": "1.23x",
          "pos": [
            1332,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true,
          "opacity_keys": [
            [
              0,
              78
            ],
            [
              5.58,
              78
            ],
            [
              5.63,
              100
            ]
          ]
        },
        {
          "type": "text",
          "name": "LANE 05 / number",
          "text": "05",
          "pos": [
            1332,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "COIN 06 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            1570,
            340
          ]
        },
        {
          "type": "text",
          "name": "COIN 06 / multiplier",
          "text": "1.29x",
          "pos": [
            1570,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "LANE 06 / number",
          "text": "06",
          "pos": [
            1570,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "COIN 07 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            1808,
            340
          ]
        },
        {
          "type": "text",
          "name": "COIN 07 / multiplier",
          "text": "1.36x",
          "pos": [
            1808,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "LANE 07 / number",
          "text": "07",
          "pos": [
            1808,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "COIN 08 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            2046,
            340
          ]
        },
        {
          "type": "text",
          "name": "COIN 08 / multiplier",
          "text": "1.44x",
          "pos": [
            2046,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "LANE 08 / number",
          "text": "08",
          "pos": [
            2046,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "COIN 09 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            2284,
            340
          ]
        },
        {
          "type": "text",
          "name": "COIN 09 / multiplier",
          "text": "1.53x",
          "pos": [
            2284,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "LANE 09 / number",
          "text": "09",
          "pos": [
            2284,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "COIN 10 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            2522,
            340
          ]
        },
        {
          "type": "text",
          "name": "COIN 10 / multiplier",
          "text": "1.63x",
          "pos": [
            2522,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "LANE 10 / number",
          "text": "10",
          "pos": [
            2522,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "COIN 11 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            2760,
            340
          ]
        },
        {
          "type": "text",
          "name": "COIN 11 / multiplier",
          "text": "1.75x",
          "pos": [
            2760,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "LANE 11 / number",
          "text": "11",
          "pos": [
            2760,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "COIN 12 / inactive",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 6,
              "w": 184,
              "h": 184,
              "fill": "#2A334F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 178,
              "h": 178,
              "fill": "#505E92",
              "stroke": "#262F4B",
              "sw": 8
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 156,
              "h": 156,
              "fill": "#6776B3",
              "stroke": "#8193D0",
              "sw": 6
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 132,
              "h": 132,
              "fill": "#5D6AA2",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "line",
              "points": [
                [
                  -55,
                  -44
                ],
                [
                  -43,
                  -55
                ],
                [
                  -28,
                  -63
                ]
              ],
              "stroke": "#A3B2EC",
              "sw": 5
            }
          ],
          "pos": [
            2998,
            340
          ]
        },
        {
          "type": "text",
          "name": "COIN 12 / multiplier",
          "text": "1.88x",
          "pos": [
            2998,
            351
          ],
          "size": 37,
          "color": "#ECF0FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "LANE 12 / number",
          "text": "12",
          "pos": [
            2998,
            160
          ],
          "size": 22,
          "color": "#8491B9",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "FIRE 01 / glow",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": -20,
              "w": 205,
              "h": 55,
              "fill": "#F5A235",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            856,
            786
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.69,
              0
            ],
            [
              2.77,
              35
            ],
            [
              2.99,
              25
            ],
            [
              3.21,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "FIRE 01 / vector burst",
          "graphics": [
            {
              "type": "path",
              "vertices": [
                [
                  0,
                  0
                ],
                [
                  -59,
                  -192
                ],
                [
                  -24,
                  -155
                ],
                [
                  9,
                  -303
                ],
                [
                  61,
                  -150
                ],
                [
                  77,
                  -215
                ],
                [
                  42,
                  -1
                ]
              ],
              "ins": [
                [
                  10,
                  3
                ],
                [
                  -25,
                  68
                ],
                [
                  -4,
                  25
                ],
                [
                  3,
                  81
                ],
                [
                  -33,
                  -41
                ],
                [
                  2,
                  27
                ],
                [
                  65,
                  -23
                ]
              ],
              "outs": [
                [
                  -100,
                  -20
                ],
                [
                  12,
                  60
                ],
                [
                  7,
                  -51
                ],
                [
                  66,
                  53
                ],
                [
                  14,
                  -20
                ],
                [
                  63,
                  80
                ],
                [
                  -17,
                  5
                ]
              ],
              "fill": "#FF5831",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "path",
              "vertices": [
                [
                  3,
                  -3
                ],
                [
                  -18,
                  -150
                ],
                [
                  12,
                  -187
                ],
                [
                  47,
                  -81
                ],
                [
                  24,
                  -1
                ]
              ],
              "ins": [
                [
                  5,
                  3
                ],
                [
                  -22,
                  34
                ],
                [
                  -10,
                  83
                ],
                [
                  -18,
                  -27
                ],
                [
                  30,
                  -4
                ]
              ],
              "outs": [
                [
                  -58,
                  -35
                ],
                [
                  -2,
                  46
                ],
                [
                  63,
                  46
                ],
                [
                  28,
                  19
                ],
                [
                  -6,
                  1
                ]
              ],
              "fill": "#FFB526",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "path",
              "vertices": [
                [
                  12,
                  -4
                ],
                [
                  17,
                  -85
                ],
                [
                  28,
                  -10
                ]
              ],
              "ins": [
                [
                  6,
                  2
                ],
                [
                  -24,
                  31
                ],
                [
                  16,
                  -28
                ]
              ],
              "outs": [
                [
                  -28,
                  -17
                ],
                [
                  -3,
                  36
                ],
                [
                  -3,
                  6
                ]
              ],
              "fill": "#FFF6B5",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            846,
            790
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              2.69,
              [
                0,
                0
              ]
            ],
            [
              2.79,
              [
                105,
                130
              ]
            ],
            [
              2.89,
              [
                82,
                105
              ]
            ],
            [
              3.03,
              [
                105,
                90
              ]
            ],
            [
              3.21,
              [
                0,
                0
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "FIRE 02 / glow",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": -20,
              "w": 205,
              "h": 55,
              "fill": "#F5A235",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1570,
            786
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.82,
              0
            ],
            [
              6.9,
              35
            ],
            [
              7.12,
              25
            ],
            [
              7.34,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "FIRE 02 / vector burst",
          "graphics": [
            {
              "type": "path",
              "vertices": [
                [
                  0,
                  0
                ],
                [
                  -59,
                  -192
                ],
                [
                  -24,
                  -155
                ],
                [
                  9,
                  -303
                ],
                [
                  61,
                  -150
                ],
                [
                  77,
                  -215
                ],
                [
                  42,
                  -1
                ]
              ],
              "ins": [
                [
                  10,
                  3
                ],
                [
                  -25,
                  68
                ],
                [
                  -4,
                  25
                ],
                [
                  3,
                  81
                ],
                [
                  -33,
                  -41
                ],
                [
                  2,
                  27
                ],
                [
                  65,
                  -23
                ]
              ],
              "outs": [
                [
                  -100,
                  -20
                ],
                [
                  12,
                  60
                ],
                [
                  7,
                  -51
                ],
                [
                  66,
                  53
                ],
                [
                  14,
                  -20
                ],
                [
                  63,
                  80
                ],
                [
                  -17,
                  5
                ]
              ],
              "fill": "#FF5831",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "path",
              "vertices": [
                [
                  3,
                  -3
                ],
                [
                  -18,
                  -150
                ],
                [
                  12,
                  -187
                ],
                [
                  47,
                  -81
                ],
                [
                  24,
                  -1
                ]
              ],
              "ins": [
                [
                  5,
                  3
                ],
                [
                  -22,
                  34
                ],
                [
                  -10,
                  83
                ],
                [
                  -18,
                  -27
                ],
                [
                  30,
                  -4
                ]
              ],
              "outs": [
                [
                  -58,
                  -35
                ],
                [
                  -2,
                  46
                ],
                [
                  63,
                  46
                ],
                [
                  28,
                  19
                ],
                [
                  -6,
                  1
                ]
              ],
              "fill": "#FFB526",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "path",
              "vertices": [
                [
                  12,
                  -4
                ],
                [
                  17,
                  -85
                ],
                [
                  28,
                  -10
                ]
              ],
              "ins": [
                [
                  6,
                  2
                ],
                [
                  -24,
                  31
                ],
                [
                  16,
                  -28
                ]
              ],
              "outs": [
                [
                  -28,
                  -17
                ],
                [
                  -3,
                  36
                ],
                [
                  -3,
                  6
                ]
              ],
              "fill": "#FFF6B5",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1560,
            790
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              6.82,
              [
                0,
                0
              ]
            ],
            [
              6.92,
              [
                105,
                130
              ]
            ],
            [
              7.02,
              [
                82,
                105
              ]
            ],
            [
              7.16,
              [
                105,
                90
              ]
            ],
            [
              7.34,
              [
                0,
                0
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "ROAD / kerb shadow",
          "graphics": [
            {
              "type": "rect",
              "x": 1615,
              "y": 804,
              "w": 3230,
              "h": 26,
              "fill": "#1D2338",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "ROAD / kerb top",
          "graphics": [
            {
              "type": "rect",
              "x": 1615,
              "y": 794,
              "w": 3230,
              "h": 7,
              "fill": "#8592BD",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "ROAD / kerb bottom",
          "graphics": [
            {
              "type": "rect",
              "x": 1615,
              "y": 834,
              "w": 3230,
              "h": 54,
              "fill": "#30374F",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 00",
          "graphics": [
            {
              "type": "rect",
              "x": 142,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#343B52",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 01",
          "graphics": [
            {
              "type": "rect",
              "x": 380,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#39415B",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 02",
          "graphics": [
            {
              "type": "rect",
              "x": 618,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#343B52",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 03",
          "graphics": [
            {
              "type": "rect",
              "x": 856,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#39415B",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 04",
          "graphics": [
            {
              "type": "rect",
              "x": 1094,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#343B52",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 05",
          "graphics": [
            {
              "type": "rect",
              "x": 1332,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#39415B",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 06",
          "graphics": [
            {
              "type": "rect",
              "x": 1570,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#343B52",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 07",
          "graphics": [
            {
              "type": "rect",
              "x": 1808,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#39415B",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 08",
          "graphics": [
            {
              "type": "rect",
              "x": 2046,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#343B52",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 09",
          "graphics": [
            {
              "type": "rect",
              "x": 2284,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#39415B",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 10",
          "graphics": [
            {
              "type": "rect",
              "x": 2522,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#343B52",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 11",
          "graphics": [
            {
              "type": "rect",
              "x": 2760,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#39415B",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 12",
          "graphics": [
            {
              "type": "rect",
              "x": 2998,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#343B52",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "KERB / tile 13",
          "graphics": [
            {
              "type": "rect",
              "x": 3236,
              "y": 831,
              "w": 236,
              "h": 36,
              "fill": "#39415B",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "CHICKEN / soft contact shadow",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 240,
              "h": 24,
              "fill": "#232B43",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            142,
            785
          ],
          "pos_keys": [
            [
              0,
              [
                142,
                785
              ]
            ],
            [
              0.95,
              [
                142,
                785
              ]
            ],
            [
              1.17,
              [
                275.28,
                785
              ]
            ],
            [
              1.38,
              [
                380,
                785
              ]
            ],
            [
              2.0,
              [
                380,
                785
              ]
            ],
            [
              2.22,
              [
                513.28,
                785
              ]
            ],
            [
              2.43,
              [
                618,
                785
              ]
            ],
            [
              3.05,
              [
                618,
                785
              ]
            ],
            [
              3.27,
              [
                751.28,
                785
              ]
            ],
            [
              3.48,
              [
                856,
                785
              ]
            ],
            [
              4.1,
              [
                856,
                785
              ]
            ],
            [
              4.32,
              [
                989.28,
                785
              ]
            ],
            [
              4.53,
              [
                1094,
                785
              ]
            ],
            [
              5.15,
              [
                1094,
                785
              ]
            ],
            [
              5.37,
              [
                1227.28,
                785
              ]
            ],
            [
              5.58,
              [
                1332,
                785
              ]
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              0.95,
              [
                100,
                100
              ]
            ],
            [
              1.17,
              [
                57,
                65
              ]
            ],
            [
              1.38,
              [
                110,
                110
              ]
            ],
            [
              1.51,
              [
                100,
                100
              ]
            ],
            [
              2.0,
              [
                100,
                100
              ]
            ],
            [
              2.22,
              [
                57,
                65
              ]
            ],
            [
              2.43,
              [
                110,
                110
              ]
            ],
            [
              2.56,
              [
                100,
                100
              ]
            ],
            [
              3.05,
              [
                100,
                100
              ]
            ],
            [
              3.27,
              [
                57,
                65
              ]
            ],
            [
              3.48,
              [
                110,
                110
              ]
            ],
            [
              3.61,
              [
                100,
                100
              ]
            ],
            [
              4.1,
              [
                100,
                100
              ]
            ],
            [
              4.32,
              [
                57,
                65
              ]
            ],
            [
              4.53,
              [
                110,
                110
              ]
            ],
            [
              4.66,
              [
                100,
                100
              ]
            ],
            [
              5.15,
              [
                100,
                100
              ]
            ],
            [
              5.37,
              [
                57,
                65
              ]
            ],
            [
              5.58,
              [
                110,
                110
              ]
            ],
            [
              5.71,
              [
                100,
                100
              ]
            ]
          ],
          "opacity": 55
        },
        {
          "type": "image",
          "name": "CHICKEN / generated PNG",
          "file": "assets/chicken.png",
          "pos": [
            142,
            790
          ],
          "anchor": [
            691,
            1170
          ],
          "scale": [
            25,
            25
          ],
          "pos_keys": [
            [
              0,
              [
                142,
                790
              ]
            ],
            [
              0.95,
              [
                142,
                790
              ]
            ],
            [
              1.02,
              [
                158,
                802
              ]
            ],
            [
              1.17,
              [
                275.28,
                675
              ]
            ],
            [
              1.38,
              [
                380,
                790
              ]
            ],
            [
              2.0,
              [
                380,
                790
              ]
            ],
            [
              2.07,
              [
                396,
                802
              ]
            ],
            [
              2.22,
              [
                513.28,
                675
              ]
            ],
            [
              2.43,
              [
                618,
                790
              ]
            ],
            [
              3.05,
              [
                618,
                790
              ]
            ],
            [
              3.12,
              [
                634,
                802
              ]
            ],
            [
              3.27,
              [
                751.28,
                675
              ]
            ],
            [
              3.48,
              [
                856,
                790
              ]
            ],
            [
              4.1,
              [
                856,
                790
              ]
            ],
            [
              4.17,
              [
                872,
                802
              ]
            ],
            [
              4.32,
              [
                989.28,
                675
              ]
            ],
            [
              4.53,
              [
                1094,
                790
              ]
            ],
            [
              5.15,
              [
                1094,
                790
              ]
            ],
            [
              5.22,
              [
                1110,
                802
              ]
            ],
            [
              5.37,
              [
                1227.28,
                675
              ]
            ],
            [
              5.58,
              [
                1332,
                790
              ]
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                25,
                25
              ]
            ],
            [
              0.95,
              [
                25,
                25
              ]
            ],
            [
              1.02,
              [
                28,
                22
              ]
            ],
            [
              1.11,
              [
                23,
                28
              ]
            ],
            [
              1.38,
              [
                28,
                22
              ]
            ],
            [
              1.51,
              [
                25,
                25
              ]
            ],
            [
              2.0,
              [
                25,
                25
              ]
            ],
            [
              2.07,
              [
                28,
                22
              ]
            ],
            [
              2.16,
              [
                23,
                28
              ]
            ],
            [
              2.43,
              [
                28,
                22
              ]
            ],
            [
              2.56,
              [
                25,
                25
              ]
            ],
            [
              3.05,
              [
                25,
                25
              ]
            ],
            [
              3.12,
              [
                28,
                22
              ]
            ],
            [
              3.21,
              [
                23,
                28
              ]
            ],
            [
              3.48,
              [
                28,
                22
              ]
            ],
            [
              3.61,
              [
                25,
                25
              ]
            ],
            [
              4.1,
              [
                25,
                25
              ]
            ],
            [
              4.17,
              [
                28,
                22
              ]
            ],
            [
              4.26,
              [
                23,
                28
              ]
            ],
            [
              4.53,
              [
                28,
                22
              ]
            ],
            [
              4.66,
              [
                25,
                25
              ]
            ],
            [
              5.15,
              [
                25,
                25
              ]
            ],
            [
              5.22,
              [
                28,
                22
              ]
            ],
            [
              5.31,
              [
                23,
                28
              ]
            ],
            [
              5.58,
              [
                28,
                22
              ]
            ],
            [
              5.71,
              [
                25,
                25
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              0.95,
              0
            ],
            [
              1.05,
              -9
            ],
            [
              1.21,
              7
            ],
            [
              1.38,
              0
            ],
            [
              2.0,
              0
            ],
            [
              2.1,
              -9
            ],
            [
              2.26,
              7
            ],
            [
              2.43,
              0
            ],
            [
              3.05,
              0
            ],
            [
              3.15,
              -9
            ],
            [
              3.31,
              7
            ],
            [
              3.48,
              0
            ],
            [
              4.1,
              0
            ],
            [
              4.2,
              -9
            ],
            [
              4.36,
              7
            ],
            [
              4.53,
              0
            ],
            [
              5.15,
              0
            ],
            [
              5.25,
              -9
            ],
            [
              5.41,
              7
            ],
            [
              5.58,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 1 / dust 1",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 24,
              "h": 13,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            380,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                380,
                780
              ]
            ],
            [
              1.38,
              [
                380,
                780
              ]
            ],
            [
              1.7,
              [
                420,
                756
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              1.38,
              0
            ],
            [
              1.405,
              70
            ],
            [
              1.7,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              1.38,
              [
                30,
                30
              ]
            ],
            [
              1.7,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 1 / dust 2",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 29,
              "h": 15,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            380,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                380,
                780
              ]
            ],
            [
              1.38,
              [
                380,
                780
              ]
            ],
            [
              1.7,
              [
                320,
                752
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              1.38,
              0
            ],
            [
              1.405,
              70
            ],
            [
              1.7,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              1.38,
              [
                30,
                30
              ]
            ],
            [
              1.7,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 1 / dust 3",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 34,
              "h": 17,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            380,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                380,
                780
              ]
            ],
            [
              1.38,
              [
                380,
                780
              ]
            ],
            [
              1.7,
              [
                460,
                748
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              1.38,
              0
            ],
            [
              1.405,
              70
            ],
            [
              1.7,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              1.38,
              [
                30,
                30
              ]
            ],
            [
              1.7,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 1 / dust 4",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 39,
              "h": 19,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            380,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                380,
                780
              ]
            ],
            [
              1.38,
              [
                380,
                780
              ]
            ],
            [
              1.7,
              [
                280,
                744
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              1.38,
              0
            ],
            [
              1.405,
              70
            ],
            [
              1.7,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              1.38,
              [
                30,
                30
              ]
            ],
            [
              1.7,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 2 / dust 1",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 24,
              "h": 13,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            618,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                618,
                780
              ]
            ],
            [
              2.43,
              [
                618,
                780
              ]
            ],
            [
              2.75,
              [
                658,
                756
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.43,
              0
            ],
            [
              2.455,
              70
            ],
            [
              2.75,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              2.43,
              [
                30,
                30
              ]
            ],
            [
              2.75,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 2 / dust 2",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 29,
              "h": 15,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            618,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                618,
                780
              ]
            ],
            [
              2.43,
              [
                618,
                780
              ]
            ],
            [
              2.75,
              [
                558,
                752
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.43,
              0
            ],
            [
              2.455,
              70
            ],
            [
              2.75,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              2.43,
              [
                30,
                30
              ]
            ],
            [
              2.75,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 2 / dust 3",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 34,
              "h": 17,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            618,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                618,
                780
              ]
            ],
            [
              2.43,
              [
                618,
                780
              ]
            ],
            [
              2.75,
              [
                698,
                748
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.43,
              0
            ],
            [
              2.455,
              70
            ],
            [
              2.75,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              2.43,
              [
                30,
                30
              ]
            ],
            [
              2.75,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 2 / dust 4",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 39,
              "h": 19,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            618,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                618,
                780
              ]
            ],
            [
              2.43,
              [
                618,
                780
              ]
            ],
            [
              2.75,
              [
                518,
                744
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              2.43,
              0
            ],
            [
              2.455,
              70
            ],
            [
              2.75,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              2.43,
              [
                30,
                30
              ]
            ],
            [
              2.75,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 3 / dust 1",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 24,
              "h": 13,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            856,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                856,
                780
              ]
            ],
            [
              3.48,
              [
                856,
                780
              ]
            ],
            [
              3.8,
              [
                896,
                756
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.48,
              0
            ],
            [
              3.505,
              70
            ],
            [
              3.8,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              3.48,
              [
                30,
                30
              ]
            ],
            [
              3.8,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 3 / dust 2",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 29,
              "h": 15,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            856,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                856,
                780
              ]
            ],
            [
              3.48,
              [
                856,
                780
              ]
            ],
            [
              3.8,
              [
                796,
                752
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.48,
              0
            ],
            [
              3.505,
              70
            ],
            [
              3.8,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              3.48,
              [
                30,
                30
              ]
            ],
            [
              3.8,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 3 / dust 3",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 34,
              "h": 17,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            856,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                856,
                780
              ]
            ],
            [
              3.48,
              [
                856,
                780
              ]
            ],
            [
              3.8,
              [
                936,
                748
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.48,
              0
            ],
            [
              3.505,
              70
            ],
            [
              3.8,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              3.48,
              [
                30,
                30
              ]
            ],
            [
              3.8,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 3 / dust 4",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 39,
              "h": 19,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            856,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                856,
                780
              ]
            ],
            [
              3.48,
              [
                856,
                780
              ]
            ],
            [
              3.8,
              [
                756,
                744
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.48,
              0
            ],
            [
              3.505,
              70
            ],
            [
              3.8,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              3.48,
              [
                30,
                30
              ]
            ],
            [
              3.8,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 4 / dust 1",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 24,
              "h": 13,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1094,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                1094,
                780
              ]
            ],
            [
              4.53,
              [
                1094,
                780
              ]
            ],
            [
              4.85,
              [
                1134,
                756
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.53,
              0
            ],
            [
              4.555,
              70
            ],
            [
              4.85,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              4.53,
              [
                30,
                30
              ]
            ],
            [
              4.85,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 4 / dust 2",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 29,
              "h": 15,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1094,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                1094,
                780
              ]
            ],
            [
              4.53,
              [
                1094,
                780
              ]
            ],
            [
              4.85,
              [
                1034,
                752
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.53,
              0
            ],
            [
              4.555,
              70
            ],
            [
              4.85,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              4.53,
              [
                30,
                30
              ]
            ],
            [
              4.85,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 4 / dust 3",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 34,
              "h": 17,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1094,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                1094,
                780
              ]
            ],
            [
              4.53,
              [
                1094,
                780
              ]
            ],
            [
              4.85,
              [
                1174,
                748
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.53,
              0
            ],
            [
              4.555,
              70
            ],
            [
              4.85,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              4.53,
              [
                30,
                30
              ]
            ],
            [
              4.85,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 4 / dust 4",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 39,
              "h": 19,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1094,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                1094,
                780
              ]
            ],
            [
              4.53,
              [
                1094,
                780
              ]
            ],
            [
              4.85,
              [
                994,
                744
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.53,
              0
            ],
            [
              4.555,
              70
            ],
            [
              4.85,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              4.53,
              [
                30,
                30
              ]
            ],
            [
              4.85,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 5 / dust 1",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 24,
              "h": 13,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1332,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                1332,
                780
              ]
            ],
            [
              5.58,
              [
                1332,
                780
              ]
            ],
            [
              5.9,
              [
                1372,
                756
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.58,
              0
            ],
            [
              5.605,
              70
            ],
            [
              5.9,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              5.58,
              [
                30,
                30
              ]
            ],
            [
              5.9,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 5 / dust 2",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 29,
              "h": 15,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1332,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                1332,
                780
              ]
            ],
            [
              5.58,
              [
                1332,
                780
              ]
            ],
            [
              5.9,
              [
                1272,
                752
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.58,
              0
            ],
            [
              5.605,
              70
            ],
            [
              5.9,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              5.58,
              [
                30,
                30
              ]
            ],
            [
              5.9,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 5 / dust 3",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 34,
              "h": 17,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1332,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                1332,
                780
              ]
            ],
            [
              5.58,
              [
                1332,
                780
              ]
            ],
            [
              5.9,
              [
                1412,
                748
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.58,
              0
            ],
            [
              5.605,
              70
            ],
            [
              5.9,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              5.58,
              [
                30,
                30
              ]
            ],
            [
              5.9,
              [
                140,
                140
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "LAND 5 / dust 4",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 39,
              "h": 19,
              "fill": "#C1CEE4",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            1332,
            780
          ],
          "pos_keys": [
            [
              0,
              [
                1332,
                780
              ]
            ],
            [
              5.58,
              [
                1332,
                780
              ]
            ],
            [
              5.9,
              [
                1232,
                744
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.58,
              0
            ],
            [
              5.605,
              70
            ],
            [
              5.9,
              0
            ]
          ],
          "scale_keys": [
            [
              0,
              [
                30,
                30
              ]
            ],
            [
              5.58,
              [
                30,
                30
              ]
            ],
            [
              5.9,
              [
                140,
                140
              ]
            ]
          ]
        }
      ]
    },
    "02_GAME_FIELD": {
      "w": 1080,
      "h": 870,
      "layers": [
        {
          "type": "comp",
          "name": "WORLD / horizontal scroll",
          "comp": "03_ROAD_WORLD",
          "pos": [
            0,
            0
          ],
          "pos_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              0.95,
              [
                0,
                0
              ]
            ],
            [
              1.05,
              [
                0,
                0
              ]
            ],
            [
              1.52,
              [
                0,
                0
              ]
            ],
            [
              2.0,
              [
                0,
                0
              ]
            ],
            [
              2.1,
              [
                0,
                0
              ]
            ],
            [
              2.57,
              [
                -238,
                0
              ]
            ],
            [
              3.05,
              [
                -238,
                0
              ]
            ],
            [
              3.15,
              [
                -238,
                0
              ]
            ],
            [
              3.62,
              [
                -476,
                0
              ]
            ],
            [
              4.1,
              [
                -476,
                0
              ]
            ],
            [
              4.2,
              [
                -476,
                0
              ]
            ],
            [
              4.67,
              [
                -714,
                0
              ]
            ],
            [
              5.15,
              [
                -714,
                0
              ]
            ],
            [
              5.25,
              [
                -714,
                0
              ]
            ],
            [
              5.72,
              [
                -952,
                0
              ]
            ]
          ]
        },
        {
          "type": "shape",
          "name": "HUD / top strip",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 28,
              "w": 1080,
              "h": 56,
              "fill": "#353D5B",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "HUD / online dot",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 10,
              "fill": "#50DA75",
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            50,
            28
          ]
        },
        {
          "type": "text",
          "name": "HUD / online",
          "text": "Online: 1 433",
          "pos": [
            70,
            35
          ],
          "size": 21,
          "color": "#C0CBE9",
          "align": "left",
          "bold": false
        },
        {
          "type": "text",
          "name": "HUD / difficulty",
          "text": "EASY",
          "pos": [
            1018,
            35
          ],
          "size": 21,
          "color": "#C0CBE9",
          "align": "right",
          "bold": true
        },
        {
          "type": "shape",
          "name": "HUD / hint panel",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 590,
              "h": 66,
              "fill": "#343B59",
              "r": 33,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            540,
            223
          ],
          "opacity": 85
        },
        {
          "type": "text",
          "name": "HUD / current hint",
          "text": "CROSS THE ROAD",
          "pos": [
            540,
            233
          ],
          "size": 27,
          "color": "#C3CDED",
          "align": "center",
          "bold": true,
          "text_keys": [
            [
              0,
              "CROSS THE ROAD"
            ],
            [
              1.38,
              "KEEP GOING"
            ],
            [
              4.53,
              "ONE MORE STEP"
            ],
            [
              5.58,
              "TAKE YOUR WIN"
            ],
            [
              6.55,
              "ROUND COMPLETE"
            ]
          ]
        }
      ]
    },
    "04_WIN_CARD": {
      "w": 880,
      "h": 560,
      "layers": [
        {
          "type": "shape",
          "name": "WIN / shadow",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 15,
              "w": 796,
              "h": 480,
              "fill": "#111726",
              "r": 36,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            440,
            270
          ]
        },
        {
          "type": "shape",
          "name": "WIN / card",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 796,
              "h": 480,
              "fill": "#20283E",
              "r": 36,
              "stroke": "#68768D",
              "sw": 3
            }
          ],
          "pos": [
            440,
            270
          ]
        },
        {
          "type": "shape",
          "name": "WIN / green rule",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 150,
              "h": 6,
              "fill": "#49DD77",
              "r": 3,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            440,
            66
          ]
        },
        {
          "type": "text",
          "name": "WIN / eyebrow",
          "text": "CASHED OUT",
          "pos": [
            440,
            112
          ],
          "size": 26,
          "color": "#8CDFAB",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "WIN / heading",
          "text": "WIN!",
          "pos": [
            440,
            202
          ],
          "size": 74,
          "color": "#F4F6FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "WIN / multiplier",
          "text": "x1.23",
          "pos": [
            440,
            315
          ],
          "size": 109,
          "color": "#FFCA18",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "WIN / amount",
          "text": "+61.50 $",
          "pos": [
            440,
            391
          ],
          "size": 53,
          "color": "#4BDC7D",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "WIN / detail",
          "text": "5 SAFE CROSSINGS",
          "pos": [
            440,
            449
          ],
          "size": 21,
          "color": "#A1AECF",
          "align": "center",
          "bold": true
        }
      ]
    },
    "01_CHICKEN_ROAD_VERTICAL": {
      "w": 1080,
      "h": 1920,
      "layers": [
        {
          "type": "shape",
          "name": "BACKGROUND / full frame",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 960,
              "w": 1080,
              "h": 1920,
              "fill": "#151925",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "HEADER / card",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 190,
              "w": 1080,
              "h": 380,
              "fill": "#202639",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "text",
          "name": "TITLE / CHICKEN ROAD",
          "text": "CHICKEN ROAD",
          "pos": [
            54,
            128
          ],
          "size": 66,
          "color": "#F4F6FF",
          "align": "left",
          "bold": true
        },
        {
          "type": "shape",
          "name": "TITLE / yellow underline",
          "graphics": [
            {
              "type": "rect",
              "x": 159,
              "y": 153,
              "w": 210,
              "h": 6,
              "fill": "#FFCA18",
              "r": 3,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "TITLE / demo badge",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 115,
              "h": 43,
              "fill": "#414153",
              "r": 21,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            966,
            107
          ]
        },
        {
          "type": "text",
          "name": "TITLE / demo",
          "text": "DEMO",
          "pos": [
            966,
            115
          ],
          "size": 20,
          "color": "#F4D36E",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "TITLE / subtitle",
          "text": "ONE CHICKEN. FIVE CROSSINGS.",
          "pos": [
            54,
            192
          ],
          "size": 23,
          "color": "#8D9ABE",
          "align": "left",
          "bold": false
        },
        {
          "type": "shape",
          "name": "BALANCE / shadow",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 290,
              "w": 972,
              "h": 136,
              "fill": "#141A2B",
              "r": 23,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "BALANCE / panel",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 282,
              "w": 972,
              "h": 136,
              "fill": "#2D354D",
              "r": 23,
              "stroke": "#46516E",
              "sw": 2
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "text",
          "name": "BALANCE / label",
          "text": "BALANCE",
          "pos": [
            84,
            257
          ],
          "size": 20,
          "color": "#AAB7DA",
          "align": "left",
          "bold": true
        },
        {
          "type": "text",
          "name": "BALANCE / amount",
          "text": "999 950.00",
          "pos": [
            84,
            313
          ],
          "size": 46,
          "color": "#F4F6FF",
          "align": "left",
          "bold": true,
          "text_keys": [
            [
              0,
              "1 000 000.00"
            ],
            [
              0.8,
              "999 950.00"
            ],
            [
              6.55,
              "1 000 011.50"
            ]
          ]
        },
        {
          "type": "shape",
          "name": "BALANCE / dollar coin",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 3,
              "w": 66,
              "h": 66,
              "fill": "#B27C0F",
              "stroke": null,
              "sw": 0
            },
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 66,
              "h": 66,
              "fill": "#FFCC2A",
              "stroke": "#FFE28A",
              "sw": 3
            }
          ],
          "pos": [
            950,
            282
          ]
        },
        {
          "type": "text",
          "name": "BALANCE / dollar",
          "text": "$",
          "pos": [
            950,
            294
          ],
          "size": 36,
          "color": "#956511",
          "align": "center",
          "bold": true
        },
        {
          "type": "comp",
          "name": "GAME / editable scene",
          "comp": "02_GAME_FIELD",
          "pos": [
            0,
            399
          ]
        },
        {
          "type": "shape",
          "name": "GAME / top edge",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 394,
              "w": 1080,
              "h": 6,
              "fill": "#59668D",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "GAME / bottom edge",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 1276,
              "w": 1080,
              "h": 8,
              "fill": "#101622",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "text",
          "name": "ROUND / label",
          "text": "CURRENT MULTIPLIER",
          "pos": [
            540,
            1335
          ],
          "size": 21,
          "color": "#8E9CBC",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "ROUND / current multiplier",
          "text": "1.00x",
          "pos": [
            540,
            1406
          ],
          "size": 62,
          "color": "#FFCA18",
          "align": "center",
          "bold": true,
          "text_keys": [
            [
              0,
              "1.00x"
            ],
            [
              1.38,
              "1.03x"
            ],
            [
              2.43,
              "1.07x"
            ],
            [
              3.48,
              "1.12x"
            ],
            [
              4.53,
              "1.17x"
            ],
            [
              5.58,
              "1.23x"
            ]
          ]
        },
        {
          "type": "shape",
          "name": "CONTROLS / panel shadow",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 1635,
              "w": 992,
              "h": 381,
              "fill": "#0D1220",
              "r": 30,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "shape",
          "name": "CONTROLS / panel",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 1624,
              "w": 992,
              "h": 381,
              "fill": "#292F44",
              "r": 30,
              "stroke": "#3D4764",
              "sw": 2
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "text",
          "name": "CONTROLS / bet label",
          "text": "BET AMOUNT",
          "pos": [
            84,
            1481
          ],
          "size": 19,
          "color": "#ABB7D5",
          "align": "left",
          "bold": true
        },
        {
          "type": "text",
          "name": "CONTROLS / difficulty label",
          "text": "DIFFICULTY",
          "pos": [
            589,
            1481
          ],
          "size": 19,
          "color": "#ABB7D5",
          "align": "left",
          "bold": true
        },
        {
          "type": "shape",
          "name": "CONTROLS / bet field",
          "graphics": [
            {
              "type": "rect",
              "x": 296,
              "y": 1530,
              "w": 424,
              "h": 64,
              "fill": "#3B435C",
              "r": 12,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "text",
          "name": "CONTROLS / min",
          "text": "MIN",
          "pos": [
            118,
            1538
          ],
          "size": 18,
          "color": "#8A97BB",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "CONTROLS / bet",
          "text": "50 $",
          "pos": [
            296,
            1542
          ],
          "size": 31,
          "color": "#F4F6FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "CONTROLS / max",
          "text": "MAX",
          "pos": [
            474,
            1538
          ],
          "size": 18,
          "color": "#8A97BB",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "CONTROLS / easy field",
          "graphics": [
            {
              "type": "rect",
              "x": 793,
              "y": 1530,
              "w": 410,
              "h": 64,
              "fill": "#3B435C",
              "r": 12,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 642,
              "y": 1530,
              "w": 96,
              "h": 50,
              "fill": "#53637A",
              "r": 9,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ]
        },
        {
          "type": "text",
          "name": "DIFFICULTY / Easy",
          "text": "Easy",
          "pos": [
            642,
            1539
          ],
          "size": 20,
          "color": "#F1F5FF",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "DIFFICULTY / Med",
          "text": "Med",
          "pos": [
            743,
            1539
          ],
          "size": 20,
          "color": "#8E9ABC",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "DIFFICULTY / Hard",
          "text": "Hard",
          "pos": [
            843,
            1539
          ],
          "size": 20,
          "color": "#8E9ABC",
          "align": "center",
          "bold": true
        },
        {
          "type": "text",
          "name": "DIFFICULTY / Pro",
          "text": "Pro",
          "pos": [
            943,
            1539
          ],
          "size": 20,
          "color": "#8E9ABC",
          "align": "center",
          "bold": true
        },
        {
          "type": "shape",
          "name": "CASH OUT / shadow",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 7,
              "w": 439,
              "h": 146,
              "fill": "#9B710A",
              "r": 20,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            303,
            1686
          ]
        },
        {
          "type": "shape",
          "name": "CASH OUT / button",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 439,
              "h": 146,
              "fill": "#FFCA18",
              "r": 20,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -65,
              "w": 395,
              "h": 3,
              "fill": "#FFDF70",
              "r": 1,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            303,
            1686
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              6.29,
              [
                100,
                100
              ]
            ],
            [
              6.34,
              [
                96,
                96
              ]
            ],
            [
              6.43,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "CASH OUT / title",
          "text": "CASH OUT",
          "pos": [
            303,
            1673
          ],
          "size": 34,
          "color": "#222536",
          "align": "center",
          "bold": true,
          "text_keys": [
            [
              0,
              "CASH OUT"
            ],
            [
              6.55,
              "COLLECTED"
            ]
          ]
        },
        {
          "type": "text",
          "name": "CASH OUT / amount",
          "text": "50.00 $",
          "pos": [
            303,
            1718
          ],
          "size": 35,
          "color": "#222536",
          "align": "center",
          "bold": true,
          "text_keys": [
            [
              0,
              "50.00 $"
            ],
            [
              1.38,
              "51.50 $"
            ],
            [
              2.43,
              "53.50 $"
            ],
            [
              3.48,
              "56.00 $"
            ],
            [
              4.53,
              "58.50 $"
            ],
            [
              5.58,
              "61.50 $"
            ]
          ]
        },
        {
          "type": "shape",
          "name": "GO / shadow",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 7,
              "w": 439,
              "h": 146,
              "fill": "#168539",
              "r": 20,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            778,
            1686
          ]
        },
        {
          "type": "shape",
          "name": "GO / button",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 439,
              "h": 146,
              "fill": "#30C65A",
              "r": 20,
              "stroke": null,
              "sw": 0
            },
            {
              "type": "rect",
              "x": 0,
              "y": -65,
              "w": 395,
              "h": 3,
              "fill": "#69E58C",
              "r": 1,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            778,
            1686
          ],
          "scale_keys": [
            [
              0,
              [
                100,
                100
              ]
            ],
            [
              0.92,
              [
                100,
                100
              ]
            ],
            [
              0.985,
              [
                96,
                96
              ]
            ],
            [
              1.1,
              [
                100,
                100
              ]
            ],
            [
              1.97,
              [
                100,
                100
              ]
            ],
            [
              2.035,
              [
                96,
                96
              ]
            ],
            [
              2.15,
              [
                100,
                100
              ]
            ],
            [
              3.02,
              [
                100,
                100
              ]
            ],
            [
              3.085,
              [
                96,
                96
              ]
            ],
            [
              3.2,
              [
                100,
                100
              ]
            ],
            [
              4.07,
              [
                100,
                100
              ]
            ],
            [
              4.135,
              [
                96,
                96
              ]
            ],
            [
              4.25,
              [
                100,
                100
              ]
            ],
            [
              5.12,
              [
                100,
                100
              ]
            ],
            [
              5.185,
              [
                96,
                96
              ]
            ],
            [
              5.3,
              [
                100,
                100
              ]
            ]
          ]
        },
        {
          "type": "text",
          "name": "GO / label",
          "text": "PLAY",
          "pos": [
            778,
            1703
          ],
          "size": 48,
          "color": "#F5FFF7",
          "align": "center",
          "bold": true,
          "text_keys": [
            [
              0,
              "PLAY"
            ],
            [
              0.8,
              "GO"
            ],
            [
              6.55,
              "AGAIN"
            ]
          ]
        },
        {
          "type": "text",
          "name": "CONTROLS / guidance",
          "text": "Tap GO to cross the next lane",
          "pos": [
            540,
            1792
          ],
          "size": 21,
          "color": "#98A7CD",
          "align": "center",
          "bold": false,
          "text_keys": [
            [
              0,
              "Tap GO to cross the next lane"
            ],
            [
              5.58,
              "Cash out to finish the round"
            ],
            [
              6.55,
              "Round complete. Nice crossing!"
            ]
          ]
        },
        {
          "type": "text",
          "name": "FOOTER / demo label",
          "text": "GAMEPLAY ANIMATION  /  DEMO",
          "pos": [
            540,
            1880
          ],
          "size": 18,
          "color": "#697798",
          "align": "center",
          "bold": false
        },
        {
          "type": "shape",
          "name": "INPUT / click ring 00",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 62,
              "h": 62,
              "fill": null,
              "stroke": "#FFFFFF",
              "sw": 4
            }
          ],
          "pos": [
            778,
            1686
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              0.95,
              [
                40,
                40
              ]
            ],
            [
              1.27,
              [
                180,
                180
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              0.94,
              0
            ],
            [
              0.95,
              70
            ],
            [
              1.27,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "INPUT / click ring 01",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 62,
              "h": 62,
              "fill": null,
              "stroke": "#FFFFFF",
              "sw": 4
            }
          ],
          "pos": [
            778,
            1686
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              2.0,
              [
                40,
                40
              ]
            ],
            [
              2.32,
              [
                180,
                180
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              1.99,
              0
            ],
            [
              2.0,
              70
            ],
            [
              2.32,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "INPUT / click ring 02",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 62,
              "h": 62,
              "fill": null,
              "stroke": "#FFFFFF",
              "sw": 4
            }
          ],
          "pos": [
            778,
            1686
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              3.05,
              [
                40,
                40
              ]
            ],
            [
              3.37,
              [
                180,
                180
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              3.04,
              0
            ],
            [
              3.05,
              70
            ],
            [
              3.37,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "INPUT / click ring 03",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 62,
              "h": 62,
              "fill": null,
              "stroke": "#FFFFFF",
              "sw": 4
            }
          ],
          "pos": [
            778,
            1686
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              4.1,
              [
                40,
                40
              ]
            ],
            [
              4.42,
              [
                180,
                180
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              4.09,
              0
            ],
            [
              4.1,
              70
            ],
            [
              4.42,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "INPUT / click ring 04",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 62,
              "h": 62,
              "fill": null,
              "stroke": "#FFFFFF",
              "sw": 4
            }
          ],
          "pos": [
            778,
            1686
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              5.15,
              [
                40,
                40
              ]
            ],
            [
              5.47,
              [
                180,
                180
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              5.14,
              0
            ],
            [
              5.15,
              70
            ],
            [
              5.47,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "INPUT / click ring 05",
          "graphics": [
            {
              "type": "ellipse",
              "x": 0,
              "y": 0,
              "w": 62,
              "h": 62,
              "fill": null,
              "stroke": "#FFFFFF",
              "sw": 4
            }
          ],
          "pos": [
            303,
            1686
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              6.3,
              [
                40,
                40
              ]
            ],
            [
              6.62,
              [
                180,
                180
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.29,
              0
            ],
            [
              6.3,
              70
            ],
            [
              6.62,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / backdrop",
          "graphics": [
            {
              "type": "rect",
              "x": 540,
              "y": 833,
              "w": 1080,
              "h": 878,
              "fill": "#111725",
              "r": 0,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            0,
            0
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.45,
              0
            ],
            [
              6.68,
              48
            ]
          ]
        },
        {
          "type": "comp",
          "name": "WIN / editable result",
          "comp": "04_WIN_CARD",
          "pos": [
            540,
            830
          ],
          "anchor": [
            440,
            280
          ],
          "scale_keys": [
            [
              0,
              [
                0,
                0
              ]
            ],
            [
              6.48,
              [
                0,
                0
              ]
            ],
            [
              6.68,
              [
                107,
                107
              ]
            ],
            [
              6.84,
              [
                100,
                100
              ]
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.48,
              0
            ],
            [
              6.53,
              100
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 00",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 7,
              "h": 14,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            312,
            444
          ],
          "pos_keys": [
            [
              0,
              [
                312,
                444
              ]
            ],
            [
              6.58317,
              [
                312,
                444
              ]
            ],
            [
              7.28317,
              [
                398.8,
                284
              ]
            ],
            [
              9.5,
              [
                436,
                1494
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.58317,
              0
            ],
            [
              9.5,
              440
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.57317,
              0
            ],
            [
              6.58317,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 01",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 7,
              "h": 20,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            333,
            557
          ],
          "pos_keys": [
            [
              0,
              [
                333,
                557
              ]
            ],
            [
              6.60809,
              [
                333,
                557
              ]
            ],
            [
              7.30809,
              [
                513.6,
                397
              ]
            ],
            [
              9.5,
              [
                591,
                1607
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.60809,
              0
            ],
            [
              9.5,
              -799
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.59809,
              0
            ],
            [
              6.60809,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 02",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 14,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            544,
            449
          ],
          "pos_keys": [
            [
              0,
              [
                544,
                449
              ]
            ],
            [
              6.66768,
              [
                544,
                449
              ]
            ],
            [
              7.36768,
              [
                716.2,
                289
              ]
            ],
            [
              9.5,
              [
                790,
                1499
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.66768,
              0
            ],
            [
              9.5,
              796
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.65768,
              0
            ],
            [
              6.66768,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 03",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 19,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            319,
            544
          ],
          "pos_keys": [
            [
              0,
              [
                319,
                544
              ]
            ],
            [
              6.62242,
              [
                319,
                544
              ]
            ],
            [
              7.32242,
              [
                151.0,
                384
              ]
            ],
            [
              9.5,
              [
                79,
                1594
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.62242,
              0
            ],
            [
              9.5,
              -416
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.61242,
              0
            ],
            [
              6.62242,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 04",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 14,
              "fill": "#FFCA18",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            758,
            416
          ],
          "pos_keys": [
            [
              0,
              [
                758,
                416
              ]
            ],
            [
              6.60636,
              [
                758,
                416
              ]
            ],
            [
              7.30636,
              [
                645.3,
                256
              ]
            ],
            [
              9.5,
              [
                597,
                1466
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.60636,
              0
            ],
            [
              9.5,
              359
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.59636,
              0
            ],
            [
              6.60636,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 05",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 11,
              "h": 16,
              "fill": "#F2F4FF",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            426,
            410
          ],
          "pos_keys": [
            [
              0,
              [
                426,
                410
              ]
            ],
            [
              6.66841,
              [
                426,
                410
              ]
            ],
            [
              7.36841,
              [
                305.6,
                250
              ]
            ],
            [
              9.5,
              [
                254,
                1460
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.66841,
              0
            ],
            [
              9.5,
              -895
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.65841,
              0
            ],
            [
              6.66841,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 06",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 8,
              "h": 15,
              "fill": "#FFCA18",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            907,
            386
          ],
          "pos_keys": [
            [
              0,
              [
                907,
                386
              ]
            ],
            [
              6.61864,
              [
                907,
                386
              ]
            ],
            [
              7.31864,
              [
                770.5,
                226
              ]
            ],
            [
              9.5,
              [
                712,
                1436
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.61864,
              0
            ],
            [
              9.5,
              892
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.60864,
              0
            ],
            [
              6.61864,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 07",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 15,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            547,
            536
          ],
          "pos_keys": [
            [
              0,
              [
                547,
                536
              ]
            ],
            [
              6.62688,
              [
                547,
                536
              ]
            ],
            [
              7.32688,
              [
                683.5,
                376
              ]
            ],
            [
              9.5,
              [
                742,
                1586
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.62688,
              0
            ],
            [
              9.5,
              -462
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.61688,
              0
            ],
            [
              6.62688,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 08",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 12,
              "h": 20,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            862,
            503
          ],
          "pos_keys": [
            [
              0,
              [
                862,
                503
              ]
            ],
            [
              6.64426,
              [
                862,
                503
              ]
            ],
            [
              7.34426,
              [
                749.3,
                343
              ]
            ],
            [
              9.5,
              [
                701,
                1553
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.64426,
              0
            ],
            [
              9.5,
              815
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.63426,
              0
            ],
            [
              6.64426,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 09",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 9,
              "h": 21,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            718,
            400
          ],
          "pos_keys": [
            [
              0,
              [
                718,
                400
              ]
            ],
            [
              6.60269,
              [
                718,
                400
              ]
            ],
            [
              7.30269,
              [
                757.2,
                240
              ]
            ],
            [
              9.5,
              [
                774,
                1450
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.60269,
              0
            ],
            [
              9.5,
              -373
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.59269,
              0
            ],
            [
              6.60269,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 10",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 7,
              "h": 17,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            907,
            569
          ],
          "pos_keys": [
            [
              0,
              [
                907,
                569
              ]
            ],
            [
              6.6013,
              [
                907,
                569
              ]
            ],
            [
              7.3013,
              [
                1088.3,
                409
              ]
            ],
            [
              9.5,
              [
                1166,
                1619
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.6013,
              0
            ],
            [
              9.5,
              651
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.5913,
              0
            ],
            [
              6.6013,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 11",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 9,
              "h": 24,
              "fill": "#F2F4FF",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            305,
            418
          ],
          "pos_keys": [
            [
              0,
              [
                305,
                418
              ]
            ],
            [
              6.59057,
              [
                305,
                418
              ]
            ],
            [
              7.29057,
              [
                146.8,
                258
              ]
            ],
            [
              9.5,
              [
                79,
                1468
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.59057,
              0
            ],
            [
              9.5,
              -726
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.58057,
              0
            ],
            [
              6.59057,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 12",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 12,
              "h": 13,
              "fill": "#FFCA18",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            259,
            518
          ],
          "pos_keys": [
            [
              0,
              [
                259,
                518
              ]
            ],
            [
              6.57994,
              [
                259,
                518
              ]
            ],
            [
              7.27994,
              [
                360.5,
                358
              ]
            ],
            [
              9.5,
              [
                404,
                1568
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.57994,
              0
            ],
            [
              9.5,
              506
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.56994,
              0
            ],
            [
              6.57994,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 13",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 18,
              "fill": "#FFCA18",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            864,
            391
          ],
          "pos_keys": [
            [
              0,
              [
                864,
                391
              ]
            ],
            [
              6.56159,
              [
                864,
                391
              ]
            ],
            [
              7.26159,
              [
                896.9,
                231
              ]
            ],
            [
              9.5,
              [
                911,
                1441
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.56159,
              0
            ],
            [
              9.5,
              -474
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.55159,
              0
            ],
            [
              6.56159,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 14",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 19,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            662,
            461
          ],
          "pos_keys": [
            [
              0,
              [
                662,
                461
              ]
            ],
            [
              6.60921,
              [
                662,
                461
              ]
            ],
            [
              7.30921,
              [
                645.9,
                301
              ]
            ],
            [
              9.5,
              [
                639,
                1511
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.60921,
              0
            ],
            [
              9.5,
              727
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.59921,
              0
            ],
            [
              6.60921,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 15",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 7,
              "h": 14,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            162,
            500
          ],
          "pos_keys": [
            [
              0,
              [
                162,
                500
              ]
            ],
            [
              6.64602,
              [
                162,
                500
              ]
            ],
            [
              7.34602,
              [
                29.700000000000017,
                340
              ]
            ],
            [
              9.5,
              [
                -27,
                1550
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.64602,
              0
            ],
            [
              9.5,
              -409
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.63602,
              0
            ],
            [
              6.64602,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 16",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 11,
              "h": 20,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            862,
            483
          ],
          "pos_keys": [
            [
              0,
              [
                862,
                483
              ]
            ],
            [
              6.65692,
              [
                862,
                483
              ]
            ],
            [
              7.35692,
              [
                937.6,
                323
              ]
            ],
            [
              9.5,
              [
                970,
                1533
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.65692,
              0
            ],
            [
              9.5,
              452
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.64692,
              0
            ],
            [
              6.65692,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 17",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 9,
              "h": 19,
              "fill": "#FFCA18",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            698,
            366
          ],
          "pos_keys": [
            [
              0,
              [
                698,
                366
              ]
            ],
            [
              6.66951,
              [
                698,
                366
              ]
            ],
            [
              7.36951,
              [
                651.8,
                206
              ]
            ],
            [
              9.5,
              [
                632,
                1416
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.66951,
              0
            ],
            [
              9.5,
              -887
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.65951,
              0
            ],
            [
              6.66951,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 18",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 9,
              "h": 13,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            203,
            540
          ],
          "pos_keys": [
            [
              0,
              [
                203,
                540
              ]
            ],
            [
              6.59905,
              [
                203,
                540
              ]
            ],
            [
              7.29905,
              [
                235.2,
                380
              ]
            ],
            [
              9.5,
              [
                249,
                1590
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.59905,
              0
            ],
            [
              9.5,
              810
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.58905,
              0
            ],
            [
              6.59905,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 19",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 20,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            295,
            365
          ],
          "pos_keys": [
            [
              0,
              [
                295,
                365
              ]
            ],
            [
              6.58134,
              [
                295,
                365
              ]
            ],
            [
              7.28134,
              [
                136.10000000000002,
                205
              ]
            ],
            [
              9.5,
              [
                68,
                1415
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.58134,
              0
            ],
            [
              9.5,
              -423
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.57134,
              0
            ],
            [
              6.58134,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 20",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 8,
              "h": 19,
              "fill": "#F2F4FF",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            165,
            401
          ],
          "pos_keys": [
            [
              0,
              [
                165,
                401
              ]
            ],
            [
              6.65737,
              [
                165,
                401
              ]
            ],
            [
              7.35737,
              [
                143.3,
                241
              ]
            ],
            [
              9.5,
              [
                134,
                1451
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.65737,
              0
            ],
            [
              9.5,
              424
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.64737,
              0
            ],
            [
              6.65737,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 21",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 11,
              "h": 24,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            191,
            498
          ],
          "pos_keys": [
            [
              0,
              [
                191,
                498
              ]
            ],
            [
              6.64632,
              [
                191,
                498
              ]
            ],
            [
              7.34632,
              [
                333.1,
                338
              ]
            ],
            [
              9.5,
              [
                394,
                1548
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.64632,
              0
            ],
            [
              9.5,
              -392
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.63632,
              0
            ],
            [
              6.64632,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 22",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 7,
              "h": 16,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            812,
            470
          ],
          "pos_keys": [
            [
              0,
              [
                812,
                470
              ]
            ],
            [
              6.61464,
              [
                812,
                470
              ]
            ],
            [
              7.31464,
              [
                912.1,
                310
              ]
            ],
            [
              9.5,
              [
                955,
                1520
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.61464,
              0
            ],
            [
              9.5,
              350
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.60464,
              0
            ],
            [
              6.61464,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 23",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 12,
              "h": 22,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            536,
            378
          ],
          "pos_keys": [
            [
              0,
              [
                536,
                378
              ]
            ],
            [
              6.64702,
              [
                536,
                378
              ]
            ],
            [
              7.34702,
              [
                431.0,
                218
              ]
            ],
            [
              9.5,
              [
                386,
                1428
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.64702,
              0
            ],
            [
              9.5,
              -926
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.63702,
              0
            ],
            [
              6.64702,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 24",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 12,
              "h": 22,
              "fill": "#F2F4FF",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            103,
            517
          ],
          "pos_keys": [
            [
              0,
              [
                103,
                517
              ]
            ],
            [
              6.62335,
              [
                103,
                517
              ]
            ],
            [
              7.32335,
              [
                181.39999999999998,
                357
              ]
            ],
            [
              9.5,
              [
                215,
                1567
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.62335,
              0
            ],
            [
              9.5,
              814
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.61335,
              0
            ],
            [
              6.62335,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 25",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 24,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            918,
            530
          ],
          "pos_keys": [
            [
              0,
              [
                918,
                530
              ]
            ],
            [
              6.59889,
              [
                918,
                530
              ]
            ],
            [
              7.29889,
              [
                879.5,
                370
              ]
            ],
            [
              9.5,
              [
                863,
                1580
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.59889,
              0
            ],
            [
              9.5,
              -832
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.58889,
              0
            ],
            [
              6.59889,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 26",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 7,
              "h": 24,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            742,
            400
          ],
          "pos_keys": [
            [
              0,
              [
                742,
                400
              ]
            ],
            [
              6.63358,
              [
                742,
                400
              ]
            ],
            [
              7.33358,
              [
                564.2,
                240
              ]
            ],
            [
              9.5,
              [
                488,
                1450
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.63358,
              0
            ],
            [
              9.5,
              628
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.62358,
              0
            ],
            [
              6.63358,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 27",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 12,
              "h": 18,
              "fill": "#FFCA18",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            492,
            407
          ],
          "pos_keys": [
            [
              0,
              [
                492,
                407
              ]
            ],
            [
              6.62568,
              [
                492,
                407
              ]
            ],
            [
              7.32568,
              [
                522.1,
                247
              ]
            ],
            [
              9.5,
              [
                535,
                1457
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.62568,
              0
            ],
            [
              9.5,
              -628
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.61568,
              0
            ],
            [
              6.62568,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 28",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 7,
              "h": 16,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            608,
            427
          ],
          "pos_keys": [
            [
              0,
              [
                608,
                427
              ]
            ],
            [
              6.63817,
              [
                608,
                427
              ]
            ],
            [
              7.33817,
              [
                681.5,
                267
              ]
            ],
            [
              9.5,
              [
                713,
                1477
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.63817,
              0
            ],
            [
              9.5,
              796
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.62817,
              0
            ],
            [
              6.63817,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 29",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 11,
              "h": 19,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            458,
            446
          ],
          "pos_keys": [
            [
              0,
              [
                458,
                446
              ]
            ],
            [
              6.59486,
              [
                458,
                446
              ]
            ],
            [
              7.29486,
              [
                499.3,
                286
              ]
            ],
            [
              9.5,
              [
                517,
                1496
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.59486,
              0
            ],
            [
              9.5,
              -836
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.58486,
              0
            ],
            [
              6.59486,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 30",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 8,
              "h": 20,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            787,
            536
          ],
          "pos_keys": [
            [
              0,
              [
                787,
                536
              ]
            ],
            [
              6.64077,
              [
                787,
                536
              ]
            ],
            [
              7.34077,
              [
                859.8,
                376
              ]
            ],
            [
              9.5,
              [
                891,
                1586
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.64077,
              0
            ],
            [
              9.5,
              841
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.63077,
              0
            ],
            [
              6.64077,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 31",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 24,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            599,
            564
          ],
          "pos_keys": [
            [
              0,
              [
                599,
                564
              ]
            ],
            [
              6.57961,
              [
                599,
                564
              ]
            ],
            [
              7.27961,
              [
                475.1,
                404
              ]
            ],
            [
              9.5,
              [
                422,
                1614
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.57961,
              0
            ],
            [
              9.5,
              -577
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.56961,
              0
            ],
            [
              6.57961,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 32",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 9,
              "h": 21,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            509,
            549
          ],
          "pos_keys": [
            [
              0,
              [
                509,
                549
              ]
            ],
            [
              6.67841,
              [
                509,
                549
              ]
            ],
            [
              7.37841,
              [
                410.3,
                389
              ]
            ],
            [
              9.5,
              [
                368,
                1599
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.67841,
              0
            ],
            [
              9.5,
              575
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.66841,
              0
            ],
            [
              6.67841,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 33",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 8,
              "h": 21,
              "fill": "#59E482",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            363,
            511
          ],
          "pos_keys": [
            [
              0,
              [
                363,
                511
              ]
            ],
            [
              6.60336,
              [
                363,
                511
              ]
            ],
            [
              7.30336,
              [
                475.7,
                351
              ]
            ],
            [
              9.5,
              [
                524,
                1561
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.60336,
              0
            ],
            [
              9.5,
              -768
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.59336,
              0
            ],
            [
              6.60336,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 34",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 7,
              "h": 14,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            335,
            409
          ],
          "pos_keys": [
            [
              0,
              [
                335,
                409
              ]
            ],
            [
              6.6196,
              [
                335,
                409
              ]
            ],
            [
              7.3196,
              [
                293.0,
                249
              ]
            ],
            [
              9.5,
              [
                275,
                1459
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.6196,
              0
            ],
            [
              9.5,
              697
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.6096,
              0
            ],
            [
              6.6196,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 35",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 8,
              "h": 13,
              "fill": "#F2F4FF",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            166,
            517
          ],
          "pos_keys": [
            [
              0,
              [
                166,
                517
              ]
            ],
            [
              6.67045,
              [
                166,
                517
              ]
            ],
            [
              7.37045,
              [
                105.80000000000001,
                357
              ]
            ],
            [
              9.5,
              [
                80,
                1567
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.67045,
              0
            ],
            [
              9.5,
              -924
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.66045,
              0
            ],
            [
              6.67045,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 36",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 10,
              "h": 23,
              "fill": "#FFCA18",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            275,
            525
          ],
          "pos_keys": [
            [
              0,
              [
                275,
                525
              ]
            ],
            [
              6.57145,
              [
                275,
                525
              ]
            ],
            [
              7.27145,
              [
                282.0,
                365
              ]
            ],
            [
              9.5,
              [
                285,
                1575
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.57145,
              0
            ],
            [
              9.5,
              589
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.56145,
              0
            ],
            [
              6.57145,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        },
        {
          "type": "shape",
          "name": "WIN / confetti 37",
          "graphics": [
            {
              "type": "rect",
              "x": 0,
              "y": 0,
              "w": 12,
              "h": 14,
              "fill": "#99ACED",
              "r": 2,
              "stroke": null,
              "sw": 0
            }
          ],
          "pos": [
            659,
            373
          ],
          "pos_keys": [
            [
              0,
              [
                659,
                373
              ]
            ],
            [
              6.6638,
              [
                659,
                373
              ]
            ],
            [
              7.3638,
              [
                567.3,
                213
              ]
            ],
            [
              9.5,
              [
                528,
                1423
              ]
            ]
          ],
          "rotation_keys": [
            [
              0,
              0
            ],
            [
              6.6638,
              0
            ],
            [
              9.5,
              -627
            ]
          ],
          "opacity_keys": [
            [
              0,
              0
            ],
            [
              6.6538,
              0
            ],
            [
              6.6638,
              100
            ],
            [
              9.1,
              100
            ],
            [
              9.5,
              0
            ]
          ]
        }
      ]
    }
  },
  "palette": {
    "bg": "#151925",
    "panel": "#292F44",
    "panel2": "#363D54",
    "road": "#3C4264",
    "white": "#F4F6FF",
    "muted": "#A8B3D9",
    "line": "#717FA9",
    "yellow": "#FFCA18",
    "green": "#30C65A",
    "dark": "#151B2D",
    "blue": "#626FA8"
  },
  "markers": [
    [
      "START",
      0
    ],
    [
      "HOP 1",
      0.95
    ],
    [
      "HOP 2",
      2.0
    ],
    [
      "HOP 3",
      3.05
    ],
    [
      "HOP 4",
      4.1000000000000005
    ],
    [
      "HOP 5",
      5.15
    ],
    [
      "CASH OUT",
      6.3
    ],
    [
      "WIN",
      6.55
    ]
  ],
  "master": "01_CHICKEN_ROAD_VERTICAL",
  "audio": [
    {
      "file": "assets/hop.wav",
      "time": 1.02
    },
    {
      "file": "assets/hop.wav",
      "time": 2.07
    },
    {
      "file": "assets/hop.wav",
      "time": 3.1199999999999997
    },
    {
      "file": "assets/hop.wav",
      "time": 4.170000000000001
    },
    {
      "file": "assets/hop.wav",
      "time": 5.220000000000001
    },
    {
      "file": "assets/coin.wav",
      "time": 1.38
    },
    {
      "file": "assets/coin.wav",
      "time": 2.43
    },
    {
      "file": "assets/coin.wav",
      "time": 3.48
    },
    {
      "file": "assets/coin.wav",
      "time": 4.53
    },
    {
      "file": "assets/coin.wav",
      "time": 5.58
    },
    {
      "file": "assets/fire.wav",
      "time": 2.69
    },
    {
      "file": "assets/fire.wav",
      "time": 6.82
    },
    {
      "file": "assets/cashout.wav",
      "time": 6.55
    }
  ]
};
    var BASE = File($.fileName).parent;
    var FONT_REGULAR = "ArialMT";
    var FONT_BOLD = "Arial-BoldMT";
    var comps = {}, imported = {}, built = {}, notes = [], groupOpen = false;
    var project, folderScene, folderImages, folderAudio;

    function rgb(hex) {
        return [parseInt(hex.substr(1,2),16)/255,parseInt(hex.substr(3,2),16)/255,parseInt(hex.substr(5,2),16)/255];
    }
    function scalarSlider(layer, name, val) {
        var e=layer.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
        e.name=name; e.property(1).setValue(val); return e.property(1);
    }
    function key(prop, keys, hold) {
        for(var i=0;i<keys.length;i++) {
            prop.setValueAtTime(keys[i][0],keys[i][1]);
            var n=prop.nearestKeyIndex(keys[i][0]);
            prop.setInterpolationTypeAtKey(n,hold?KeyframeInterpolationType.HOLD:KeyframeInterpolationType.LINEAR,
                hold?KeyframeInterpolationType.HOLD:KeyframeInterpolationType.LINEAR);
            if(prop.isSpatial) {
                prop.setSpatialAutoBezierAtKey(n,false);
                prop.setSpatialContinuousAtKey(n,false);
                prop.setSpatialTangentsAtKey(n,[0,0],[0,0]);
            }
        }
    }
    function transform(layer,spec) {
        var tr=layer.property("ADBE Transform Group");
        if(spec.type!=="text") tr.property("ADBE Anchor Point").setValue(spec.anchor||[0,0]);
        var p=tr.property("ADBE Position");p.setValue(spec.pos||[0,0]);
        if(spec.pos_keys)key(p,spec.pos_keys,false);
        p=tr.property("ADBE Scale");p.setValue(spec.scale||[100,100]);
        if(spec.scale_keys)key(p,spec.scale_keys,false);
        p=tr.property("ADBE Rotate Z");p.setValue(spec.rotation||0);
        if(spec.rotation_keys)key(p,spec.rotation_keys,false);
        p=tr.property("ADBE Opacity");p.setValue(spec.opacity===undefined?100:spec.opacity);
        if(spec.opacity_keys)key(p,spec.opacity_keys,false);
        layer.motionBlur=false;
        if(spec.type==="image")layer.label=9;
        else if(spec.type==="text")layer.label=14;
        else if(spec.type==="comp")layer.label=10;
        else layer.label=8;
    }
    function addGraphic(contents,g,index) {
        // Reacquire indexed property groups after addProperty(), which invalidates references in AE.
        var gr=contents.addProperty("ADBE Vector Group");gr.name=(index+1)+" / "+g.type;
        var gc=gr.property("ADBE Vectors Group"), pathObj;
        if(g.type==="rect") {
            pathObj=gc.addProperty("ADBE Vector Shape - Rect");
            pathObj.property("ADBE Vector Rect Size").setValue([g.w,g.h]);
            pathObj.property("ADBE Vector Rect Position").setValue([g.x,g.y]);
            pathObj.property("ADBE Vector Rect Roundness").setValue(g.r||0);
        } else if(g.type==="ellipse") {
            pathObj=gc.addProperty("ADBE Vector Shape - Ellipse");
            pathObj.property("ADBE Vector Ellipse Size").setValue([g.w,g.h]);
            pathObj.property("ADBE Vector Ellipse Position").setValue([g.x,g.y]);
        } else {
            pathObj=gc.addProperty("ADBE Vector Shape - Group");
            var s=new Shape(),vs=g.vertices||g.points,ins=[],outs=[];
            for(var j=0;j<vs.length;j++){ins.push([0,0]);outs.push([0,0]);}
            s.vertices=vs;s.inTangents=g.ins||ins;s.outTangents=g.outs||outs;
            s.closed=g.type!=="line";
            pathObj.property("ADBE Vector Shape").setValue(s);
        }
        if(g.fill) {
            var f=gc.addProperty("ADBE Vector Graphic - Fill");
            f.property("ADBE Vector Fill Color").setValue(rgb(g.fill));
            f.property("ADBE Vector Fill Opacity").setValue(100);
        }
        if(g.stroke && g.sw>0) {
            var st=gc.addProperty("ADBE Vector Graphic - Stroke");
            st.property("ADBE Vector Stroke Color").setValue(rgb(g.stroke));
            st.property("ADBE Vector Stroke Width").setValue(g.sw);
            st.property("ADBE Vector Stroke Line Cap").setValue(2);
            st.property("ADBE Vector Stroke Line Join").setValue(2);
        }
    }
    function textDocument(spec,value) {
        var td=new TextDocument(value);
        td.font=spec.bold?FONT_BOLD:FONT_REGULAR;
        td.fontSize=spec.size;td.applyFill=true;td.fillColor=rgb(spec.color);
        td.applyStroke=false;td.tracking=0;
        td.justification=spec.align==="left"?ParagraphJustification.LEFT_JUSTIFY:
            (spec.align==="right"?ParagraphJustification.RIGHT_JUSTIFY:ParagraphJustification.CENTER_JUSTIFY);
        return td;
    }
    function asset(path) {
        if(imported[path])return imported[path];
        var f=File(BASE.fsName+"/"+path);
        if(!f.exists)throw Error("Missing asset: "+f.fsName+". Unzip the entire folder first.");
        var op=new ImportOptions(f), item=project.importFile(op);
        item.parentFolder=/\.wav$/i.test(path)?folderAudio:folderImages;
        if(/\.png$/i.test(path)) {
            try{item.mainSource.alphaMode=AlphaMode.STRAIGHT;}catch(ignore){}
        }
        imported[path]=item;return item;
    }
    function build(name) {
        if(built[name])return comps[name];
        var c=comps[name], src=SCENE.comps[name];
        for(var i=0;i<src.layers.length;i++) {
            var spec=src.layers[i],layer;
            if(spec.type==="shape") {
                layer=c.layers.addShape();
                for(var j=0;j<spec.graphics.length;j++)
                    addGraphic(layer.property("ADBE Root Vectors Group"),spec.graphics[j],j);
            } else if(spec.type==="text") {
                layer=c.layers.addText(spec.text);
                var tp=layer.property("ADBE Text Properties").property("ADBE Text Document");
                tp.setValue(textDocument(spec,spec.text));
                if(spec.text_keys) {
                    for(var z=0;z<spec.text_keys.length;z++) {
                        tp.setValueAtTime(spec.text_keys[z][0],textDocument(spec,spec.text_keys[z][1]));
                        var ki=tp.nearestKeyIndex(spec.text_keys[z][0]);
                        tp.setInterpolationTypeAtKey(ki,KeyframeInterpolationType.HOLD,KeyframeInterpolationType.HOLD);
                    }
                }
            } else if(spec.type==="image")layer=c.layers.add(asset(spec.file));
            else if(spec.type==="comp")layer=c.layers.add(build(spec.comp));
            else throw Error("Unsupported layer type: "+spec.type);
            layer.name=spec.name;layer.startTime=0;layer.inPoint=0;layer.outPoint=SCENE.duration;
            transform(layer,spec);
        }
        built[name]=true;return c;
    }
    function setTextExpression(comp,layerName,expression) {
        var p=comp.layer(layerName).property("ADBE Text Properties").property("ADBE Text Document");
        p.expression=expression;
    }
    function collectExpressionErrors() {
        var bad=[];
        function walk(group,prefix) {
            for(var p=1;p<=group.numProperties;p++) {
                var q=group.property(p);
                if(q.propertyType===PropertyType.PROPERTY) {
                    if(q.canSetExpression && q.expressionEnabled && q.expressionError)
                        bad.push(prefix+" / "+q.name+": "+q.expressionError);
                } else walk(q,prefix+" / "+q.name);
            }
        }
        for(var nm in comps) if(comps.hasOwnProperty(nm)) {
            for(var n=1;n<=comps[nm].numLayers;n++)walk(comps[nm].layer(n),nm+" / "+comps[nm].layer(n).name);
        }
        return bad;
    }
    try {
        if(!File(BASE.fsName+"/assets/chicken.png").exists)
            throw Error("Keep BUILD_CHICKEN_ROAD.jsx beside the assets folder. Extract the whole ZIP.");
        if(app.project && app.project.numItems>0) {
            if(!confirm("Chicken Road will create a NEW project. Save your current project when After Effects asks. Continue?"))return;
        }
        project=app.newProject();
        if(!project)return; // Native save dialog was cancelled.
        app.beginUndoGroup("Build Chicken Road Vertical");groupOpen=true;
        project.bitsPerChannel=8;
        try{project.workingSpace="sRGB IEC61966-2.1";}catch(ignore){}
        folderScene=project.items.addFolder("01_COMPOSITIONS");
        folderImages=project.items.addFolder("02_GRAPHICS");
        folderAudio=project.items.addFolder("03_SFX");
        for(var name in SCENE.comps)if(SCENE.comps.hasOwnProperty(name)) {
            var spec=SCENE.comps[name];
            var co=project.items.addComp(name,spec.w,spec.h,1,SCENE.duration,SCENE.fps);
            co.parentFolder=folderScene;co.bgColor=rgb("#151925");co.motionBlur=false;
            co.workAreaStart=0;co.workAreaDuration=SCENE.duration;comps[name]=co;
        }
        var master=build(SCENE.master);
        var ctrl=master.layers.addNull(SCENE.duration);ctrl.name="00_CONTROLS";ctrl.label=1;ctrl.guideLayer=true;
        ctrl.comment="BET_AMOUNT and START_BALANCE update all amounts. ROUND_MULTIPLIER has 5 hold keyframes. SFX_VOLUME_DB controls every sound. Native shapes/text; no plugins.";
        scalarSlider(ctrl,"BET_AMOUNT",50);
        scalarSlider(ctrl,"START_BALANCE",1000000);
        scalarSlider(ctrl,"SFX_VOLUME_DB",-4);
        var m=scalarSlider(ctrl,"ROUND_MULTIPLIER",1);
        key(m,[[0,1],[1.38,1.03],[2.43,1.07],[3.48,1.12],[4.53,1.17],[5.58,1.23]],true);
        var ct="thisComp.layer('00_CONTROLS')";
        setTextExpression(master,"ROUND / current multiplier",ct+".effect('ROUND_MULTIPLIER')(1).toFixed(2)+'x';");
        setTextExpression(master,"CONTROLS / bet",ct+".effect('BET_AMOUNT')(1).toFixed(0)+' $';");
        setTextExpression(master,"CASH OUT / amount","var c="+ct+";(c.effect('BET_AMOUNT')(1)*c.effect('ROUND_MULTIPLIER')(1)).toFixed(2)+' $';");
        setTextExpression(master,"BALANCE / amount","var c="+ct+";var b=c.effect('BET_AMOUNT')(1);var v=c.effect('START_BALANCE')(1);if(time>=0.8)v-=b;if(time>=6.55)v+=b*c.effect('ROUND_MULTIPLIER')(1);var s=v.toFixed(2).split('.');s[0]=s[0].replace(/\\B(?=(\\d{3})+(?!\\d))/g,' ');s.join('.');");
        var mc="comp('"+SCENE.master+"').layer('00_CONTROLS')";
        setTextExpression(comps['04_WIN_CARD'],"WIN / amount","var c="+mc+";'+'+(c.effect('BET_AMOUNT')(1)*c.effect('ROUND_MULTIPLIER')(1)).toFixed(2)+' $';");
        setTextExpression(comps['04_WIN_CARD'],"WIN / multiplier","'x'+"+mc+".effect('ROUND_MULTIPLIER')(1).toFixed(2);");
        for(var a=0;a<SCENE.audio.length;a++) {
            var evt=SCENE.audio[a],sound=master.layers.add(asset(evt.file));
            sound.name="SFX / "+evt.file.split('/').pop()+" / "+evt.time.toFixed(2);
            sound.startTime=evt.time;sound.inPoint=evt.time;sound.outPoint=Math.min(SCENE.duration,evt.time+sound.source.duration);
            sound.moveToEnd();sound.label=4;
            sound.property('ADBE Audio Group').property('ADBE Audio Levels').expression="var v=thisComp.layer('00_CONTROLS').effect('SFX_VOLUME_DB')(1);[v,v];";
        }
        for(var q=0;q<SCENE.markers.length;q++) {
            var mark=new MarkerValue(SCENE.markers[q][0]);master.markerProperty.setValueAtTime(SCENE.markers[q][1],mark);
        }
        // Force expression evaluation at representative gameplay and payout frames.
        master.time=5.9;
        var problems=collectExpressionErrors();
        if(problems.length)notes.push("Expression diagnostics:\n"+problems.join('\n'));
        master.openInViewer();
        var target=File(BASE.fsName+"/Chicken_Road_Vertical.aep");
        if(target.exists)target=File(BASE.fsName+"/Chicken_Road_Vertical_"+(new Date().getTime())+".aep");
        try{project.save(target);}catch(saveError){
            target=File.saveDialog("Save Chicken Road project", "*.aep");
            if(target)project.save(target);else notes.push("Project built but not saved. Use File > Save As.");
        }
        app.endUndoGroup();groupOpen=false;
        var msg="Chicken Road is ready.\n1080 x 1920 | 30 fps | 9.5 sec\n\nOpen 01_CHICKEN_ROAD_VERTICAL.\nEdit 00_CONTROLS for stake, balance and audio.\n";
        if(target)msg+="\nSaved: "+target.fsName;
        if(notes.length)msg+="\n\n"+notes.join('\n');
        alert(msg);
    } catch(err) {
        if(groupOpen){app.endUndoGroup();groupOpen=false;}
        alert("Chicken Road build failed.\n"+err.toString()+"\nLine: "+err.line+"\nThe partially built project is kept open for inspection.");
    }
})();
